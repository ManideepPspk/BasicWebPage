import {
    VIEW_GATEWAY_TYPE,
    VIEW_ALL_GATEWAY_TYPE,
    VIEW_ALL_GATEWAY_PROVIDER,
    VIEW_GATEWAY_SETIINGS,
    VIEW_GATEWAY_PROVIDERS,
    VIEW_GATEWAY_PROVIDER_SETTING,
    VIEW_ALL_CHANNAL,
  } from "./types";
  
  import GatewayService from "../services/GatewayService";

  export const retrieveAllGatewayType = ( paramsData ) => async (dispatch) => {
    try {
      const res = await GatewayService.getAll(paramsData);
      dispatch({
        type: VIEW_ALL_GATEWAY_TYPE,
        payload: res.data,
      });
    } catch (err) {
      console.log(err);
    }
  };

  export const retrieveGatewayRecord = ( id ) => async (dispatch) => {
    try {
      const res = await GatewayService.get(id);
      dispatch({
        type: VIEW_GATEWAY_TYPE,
        payload: res.data,
      });
    } catch (err) {
      console.log(err);
    }
  };
  
  export const retrieveAllGatewayProvider = () => async (dispatch) => {
    try {
      const res = await GatewayService.getAllGatewayProvider();
      dispatch({
        type: VIEW_ALL_GATEWAY_PROVIDER,
        payload: res.data,
      });
    } catch (err) {
      console.log(err);
    }
  };

  export const retrieveGatewaySettings = (id) => async (dispatch) => {
    try {
      const res = await GatewayService.getGatewaySettings( id);
      dispatch({
        type: VIEW_GATEWAY_SETIINGS,
        payload: res.data,
      });
    } catch (err) {
      console.log(err);
    }
  };
  
  export const retrieveGatewayProviders = (id) => async (dispatch) => {
    try {
      const res = await GatewayService.getGatewayProviders( id);
      dispatch({
        type: VIEW_GATEWAY_PROVIDERS,
        payload: res.data,
      });
    } catch (err) {
      console.log(err);
    }
  };
  
  export const retrieveGatewayProviderSetting = (id) => async (dispatch) => {
    try {
      const res = await GatewayService.getGatewayProviderSetting( id);
      dispatch({
        type: VIEW_GATEWAY_PROVIDER_SETTING,
        payload: res.data,
      });
    } catch (err) {
      console.log(err);
    }
  };

  export const retrieveAllChannal = ( paramsData ) => async (dispatch) => {
    try {
      const res = await GatewayService.getAllChannal(paramsData);
      dispatch({
        type: VIEW_ALL_CHANNAL,
        payload: res.data,
      });
    } catch (err) {
      console.log(err);
    }
  };