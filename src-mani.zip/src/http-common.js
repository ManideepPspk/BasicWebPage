import axios from "axios";

export default axios.create({
  //baseURL: "http://localhost:8080/api",
  baseURL: "https://jsonkeeper.com",
  // baseURL: "https://api.instantwebtools.net/",
  // baseURL: "https://reqres.in/",
  headers: {
    "Content-type": "application/json"
  }
});
