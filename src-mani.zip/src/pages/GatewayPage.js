import React from 'react';

import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import ViewAllGatewayType from '../components/GatewayManagement/ViewAllGatewayType';
import ViewGatewayRecord from '../components/GatewayManagement/ViewGatewayRecord';
import ViewGatewaySettings from '../components/GatewayManagement/ViewGatewaySettings';
import AuthorizeComponent from '../components/Global/Authorize/AuthorizeComponent';
import ViewGatewayProviders from '../components/GatewayManagement/ViewGatewayProviders';
import ViewGatewayProviderSetting from '../components/GatewayManagement/ViewGatewayProviderSetting';
import EnrollGateway from '../components/GatewayManagement/EnrollGateway';
import ViewAllChannels from '../components/GatewayManagement/ViewAllChannels';

const AuthorizedViewAllGatewayType = (parentProps) => <AuthorizeComponent Component={(props) => <ViewAllGatewayType {...props} {...parentProps} />} type="list" module="gatewayManagement"  />
const AuthorizedEnrollGateway = (parentProps) => <AuthorizeComponent Component={(props) => <EnrollGateway name="settings" {...props} {...parentProps} />} type="create" module="gatewayManagement"  />
const AuthorizedViewGatewayRecord = (parentProps) => <AuthorizeComponent Component={(props) => <ViewGatewayRecord  {...props} {...parentProps} />} type="record" module="gatewayManagement"  />
const AuthorizedViewGatewaySettings = (parentProps) => <AuthorizeComponent Component={(props) => <ViewGatewaySettings {...props} {...parentProps} />} type="record" module="gatewaySetting"  />
const AuthorizedViewAllChannels = (parentProps) => <AuthorizeComponent Component={(props) => <ViewAllChannels {...props} {...parentProps} />} type="list" module="channelInfo"  />

function GatewayPage(props) {
    console.log('props', props);
    return (
        <>
            <Switch>
                <Route path={"/gatewaymanagment/EnrollGateway"} component={AuthorizedEnrollGateway} exact/>
                <Route path={"/gatewaymanagment/gatewayProviders/:id/:providercode"} component={ViewGatewayProviderSetting} exact />
                <Route path={"/gatewaymanagment/gatewayProviders/:id"} component={ViewGatewayProviders} exact />
                <Route path={"/gatewaymanagment/gatewaySettings/:id"} component={AuthorizedViewGatewaySettings} exact />
                <Route path={"/gatewaymanagment/channels"} component={AuthorizedViewAllChannels} exact />
                <Route path={"/gatewaymanagment/:id"} component={AuthorizedViewGatewayRecord} exact />
                <Route path={"/gatewaymanagment"} component={AuthorizedViewAllGatewayType} exact />
            </Switch>
        </>
    )
}
export default GatewayPage;
