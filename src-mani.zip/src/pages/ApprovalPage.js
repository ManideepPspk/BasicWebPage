import React from 'react';

import { Switch, Route } from "react-router-dom";
import ApprovalHome from '../components/Approval/ApprovalHome'

function ApprovalPage(props) {
    return (
        <Switch>
            <Route path={"/"} component={ApprovalHome} />
        </Switch>
    )
}
export default ApprovalPage;
