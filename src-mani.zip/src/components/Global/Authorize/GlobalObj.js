export const roleMapObj ={
    "DCO": {
       "entitlements":["dashboard","usermanual","faq"],
       "notification":["list","record"],
       "default":["login","logout"],
        
       "channelInfo": ["list", "record", "Unblocked", "approver"]
    },
    "CAB":{
        "AdocSending":["Single Message", " Bulk Messag"],
        "entitlements":["dashboard","usermanual","faq"],
        "notification":["list","record"],
        "default":["login","logout"]
      },
    "AMC":{
      "AdocSending":["Single Message", " Bulk Messag"],
      "entitlements":["dashboard","usermanual","faq","CCMParameter",{ "gatewayManagement": ["manageGateway"]},"channelInfo","batchJob","workflowManagement"],
      "notification":["list"],
      "default":["login","logout"],
      "ccm":["list","record","update","enable","disable","approver"],
      "gatewayManagement":["enable","disable","approver"],
      "gatewaySetting":["list","record","enable","disable","approver"],
      "gatewayProvider":["list","record","enable","disable","approver"],
      "channelInfo": ["list", "record", "Unblocked", "approver"],
      "batchJobSchedule":["list","record","enable","disable","approver"]
    },
    "PlatformAdmin":{
      "AdocSending":["approver"],
      "entitlements":[
            "dashboard",
            "usermanual",
            "faq", 
            { "accessManagement": ["manageWorkflow"] },
            { "gatewayManagement": [ "manageGateway", "viewChannelStatus"]},
            "batchJob",
            "approval"
        ],
      "notification":["list","record","create","update","delete","approver"],
      "default":["login","logout"],
      "ccm":["list","record","update","create","enable","disable","approver"],
      "gatewayManagement":["list","record","update","create","enable","disable","approver"],
      "gatewaySetting":["list","record","update","create","enable","disable","approver"],
      "gatewayProvider":["list","record","update","create","enable","disable","approver"],
      "channelInfo": ["list", "record"],
      "batchJobSchedule":["list","record","update","create","enable","disable","approver"],
      "workFlow": ["list","record","update","create","enable","disable"]
  
    },
    "SuperUser":{
      "AdocSending":["approver","Single Message", " Bulk Messag"],
      "entitlements":[
        "dashboard",
        "usermanual",
        "faq", 
        { "accessManagement": ["manageWorkflow","manageGroups","manageWorkflow"] },
        { "gatewayManagement": [ "manageGateway", "viewChannelStatus"]},
        { "maintainence": [ "manageCCM", "manageMailing", "scheduleDownTime"]},
        "batchJob",
        "adHocMessaging",
        "reports",
        "approval"
      ],
      "notification":["list","record","create","update","delete","approver"],
      "default":["login","logout"],
      "ccm":["list","record","update","create","enable","disable","approver"],
      "gatewayManagement":["list","record","update","create","enable","disable","approver"],
      "gatewaySetting":["list","record","update","create","enable","disable","approver"],
      "gatewayProvider":["list","record","update","create","enable","disable","approver"],
      "channelInfo": ["list", "record","Unblocked", "approver"],
      "batchJobSchedule":["list","record","update","create","enable","disable","approver"],
      "workFlow": ["list","record","update","create","enable","disable"]
  
    }
  }
  