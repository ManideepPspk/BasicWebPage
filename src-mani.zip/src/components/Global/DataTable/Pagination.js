import React from 'react';
import { Image } from 'react-bootstrap';
import  leftDoubleForward  from '../../../assets/icons/button-first-disabled.svg';
import  leftForward  from '../../../assets/icons/button-previous-disabled.svg';
import  rightDoubleBackward  from '../../../assets/icons/button-end-active.svg';
import  rightForward  from '../../../assets/icons/button-next-active.svg';

import './Styles/DataTable.scss';

const obtButtonObj = (canPreviousPage, canNextPage) => {
    return {
        "leftDoubleForwardObj" : {
            'buttonSource': !canPreviousPage?leftDoubleForward : rightDoubleBackward,
            'className': canPreviousPage? 'rotate': ''
        },
        "leftForwardObj" : {
            'buttonSource': !canPreviousPage?leftForward : rightForward,
            'className': canPreviousPage? 'rotate': ''
        },
        "rightForwardObj" : {
            'buttonSource': !canNextPage?leftForward : rightForward,
            'className': !canNextPage? 'rotate': ''
        },
        "rightDoubleForwardObj" :{
            'buttonSource': !canNextPage?leftDoubleForward : rightDoubleBackward,
            'className': !canNextPage? 'rotate': ''
        }
    }
}

const pagination = ({
    showPagination, canPreviousPage, canNextPage, handleServerSidePagination,
    handlePagination,
    pageCount,
    gotoPage,
    nextPage,
    previousPage,
    setPageSize,
    pageIndex,
    pageSize
} ) => {
    const {
        leftDoubleForwardObj,  leftForwardObj, rightDoubleForwardObj, rightForwardObj
    } = obtButtonObj(canPreviousPage, canNextPage) ;
    return (
    (showPagination)
        ? (
            <div className="pagination">
                <div className="showPage">
                    Show {' '}
                    <select
                    value={pageSize}
                    onChange={e => {
                        setPageSize(Number(e.target.value))
                        handlePagination(pageIndex, Number(e.target.value))
                        handleServerSidePagination && handleServerSidePagination( pageIndex, Number(e.target.value))
                    }}
                    className="highlightBox"
                    >
                        {[5,10, 20, 30, 40, 50,100].map(pgSize => (
                            <option key={pgSize} value={pgSize}>
                                {pgSize} 
                            </option>
                        ))}
                    </select>
                    {' '} rows  
                </div>     
                <div className="paginationBar">
                    <button
                        onClick={() => {
                            handlePagination(0, pageSize);
                            handleServerSidePagination && handleServerSidePagination( 0, pageSize ) 
                            gotoPage(0);
                        }}
                        disabled={!canPreviousPage}
                    >
                        <Image src={leftDoubleForwardObj.buttonSource}  className={leftDoubleForwardObj.className}/>
                    </button>{' '}
                    <button 
                        onClick={() => {
                            handlePagination(pageIndex -1, pageSize);
                            handleServerSidePagination && handleServerSidePagination( pageIndex -1, pageSize )   
                            previousPage(); 
                    }}
                        disabled={!canPreviousPage}
                    >
                        <Image src={leftForwardObj.buttonSource}  className={leftForwardObj.className} />
                    </button>{' '}
                    <span className="pageBlock">
                        Page{' '}
                        <b className="highlightBox"> {pageIndex + 1} </b> of {pageCount}
                    </span>
                    <button
                        onClick={() => {
                            handlePagination(pageIndex +1, pageSize);
                            handleServerSidePagination && handleServerSidePagination( pageIndex +1, pageSize ) 
                            nextPage();
                    }}
                        disabled={!canNextPage}
                    >
                        <Image src={rightForwardObj.buttonSource} className={rightForwardObj.className} />
                    </button>{' '}
                    <button 
                        onClick={() => {
                            handlePagination(pageCount -1, pageSize);
                            handleServerSidePagination && handleServerSidePagination( pageCount - 1, pageSize ) 
                            gotoPage(pageCount - 1);
                    }} 
                        disabled={!canNextPage}
                    >
                        <Image src={rightDoubleForwardObj.buttonSource} className={rightDoubleForwardObj.className} />
                    </button>{' '}
                    
                </div>    
            </div>  
        ): ''
    )
}
export default pagination;

