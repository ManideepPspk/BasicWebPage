import React from 'react';
import  { Form } from 'react-bootstrap';
import './switch.scss';

const Switch = (props) => (
    <Form.Check { ...props} className={`switch ${props.className}`}/>
)

export default Switch;
