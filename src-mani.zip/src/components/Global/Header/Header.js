import React, { useState, useEffect, useRef } from "react";
import {
  Navbar,
  NavDropdown,
  Form,
  FormControl,
  Container,
  ListGroup,
  Overlay, Row,Badge ,
  Popover
} from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import logowhite from "../../../assets/icons/logo-onwhite.svg";
import notification from "../../../assets/icons/icon-notification-outline.svg";
import searchIcon from "../../../assets/icons/icon-search.svg";
import { retrieveAllCCMParameter  }  from '../../../actions/ccmparameter';
import './Header.scss';


function Header(props) {
  const { isActive } = props;
  const [show, setShow] = useState(false);
  const target = useRef(null);
  console.log("i am called grt" , show ,target)

  const dispatch = useDispatch();
  let retrivedData = useSelector( state => state.ccmparameter);

  useEffect(() => {
    dispatch(retrieveAllCCMParameter());
  }, []);
  let dataToBeEdited = retrivedData.viewAllCcmParameter;
  console.log(dataToBeEdited , "dafegf")

	
  return (
    <Navbar
      bg="white"
      variant="white"
      expand="lg"
      sticky="top"
      className="d-flex flex-nowrap justify-content-between px-2 py-1"
    >
      <div>
      <Form inline>
        {isActive ? (
          ""
        ) : (
          <Navbar.Brand className="m-0 px-2 py-0">
            <img
              src={logowhite}
              width="69"
              height="24"
            />
          </Navbar.Brand>
        )}
        <div className="SearchTextCls">
       <span  className="searchIcon"><img src={searchIcon} width="16" height="16"/></span>
        <input type="text" class="form-control" placeholder="Search transaction, message,group,user..."/>

          </div>
      </Form>
      </div>
      <div className="d-inline-flex">
      <Navbar.Brand className="m-0 px-2 py-0">
           
              <>
      <img
           ref={target} onClick={() => setShow(!show)}
              src={notification}
              width="24"
              height="24"
            />
      <Overlay target={target.current} show={show} placement="bottom"
        containerPadding={140}
      >
        <Popover id="popover-basic" className="popoverMain">
          <Popover.Title>
          <Row className="ml-1">
        <strong >Notifications</strong>  <Badge pill variant="warning" text="light">{dataToBeEdited?.totalunread}</Badge> <span className="float-end">see all</span>
       </Row>
          </Popover.Title>
    <Popover.Content className="content">
     
       { dataToBeEdited &&
  dataToBeEdited.data.map((ele) => {
    return (
      <>
                                <ListGroup.Item className= { ele.isread === false ? "listgroupItemCls read" : "listgroupItemCls"}> 
                                {ele.title}

                                <div className="listItemCls">
                                {ele.timeslot}
                                </div>
                            </ListGroup.Item>
       </>
    );
  })
       }
    </Popover.Content>
  </Popover>

      </Overlay>
    </>
            
          </Navbar.Brand>
         
      
          
      <NavDropdown
        title="Dela Cruz,Juan"
        id="navbarScrollingDropdown"
        className="menu"
      >
        <NavDropdown.Item href="#action3">Action</NavDropdown.Item>
        <NavDropdown.Item href="#action4">Another action</NavDropdown.Item>
        <NavDropdown.Divider />
        <NavDropdown.Item href="#action5">Something else here</NavDropdown.Item>
      </NavDropdown>
      </div>
    </Navbar>
  );
}

export default Header;
