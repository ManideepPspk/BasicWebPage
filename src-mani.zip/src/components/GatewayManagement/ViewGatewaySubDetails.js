import React from 'react';
import { Card } from 'react-bootstrap';
import ViewDetailsGatewaySettings from './ViewDetailsGatewaySettings';
import ViewDetailsGatewayProviders from './ViewDetailsGatewayProviders';
import AuthorizeComponent from '../../components/Global/Authorize/AuthorizeComponent';

function ViewGatewaySubDetails(props){
    const { gatewaySettingsList, gatewayProviderList } = props;
    return(
        <div>
            <Card>
                <Card.Body>
                    <AuthorizeComponent
                        Component={(cprops) => <ViewDetailsGatewaySettings  gatewaySettingsList={gatewaySettingsList} {...cprops}  />}
                        type="list"
                        module="gatewaySetting"
                    />
                </Card.Body>
            </Card>
            <Card className="mt16">
                <Card.Body>
                    <ViewDetailsGatewayProviders gatewayProviderList={gatewayProviderList} />
                </Card.Body>
            </Card>
        </div>
    )
}

export default ViewGatewaySubDetails;
