import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from "react-redux";
import {
    Card, Button, Row, Col,
    Image, Spinner
} from 'react-bootstrap';
import { Link } from 'react-router-dom';
import SearchBar from '../Global/SearchBar/SearchBar';
import DataTable from '../Global/DataTable/DataTable';
import './styles/viewAllGatewayType.scss';

function ChannelList(props) { 
    const { data, col, handleClick } = props;
    return(
        <div className="ChannelInformation">
            <b>Channel Information</b>
            <div className="searchBlock mt15">
                <div className="searchCard">
                    <div className="formBlock">
                        <SearchBar labelText="Search Channel" textPlaceHolder="Input Channel Code" handleClick={handleClick}/>
                    </div>  
                </div>
            </div>
            <div className="tableBlock">
                <div className="dataBlock">
                    {
                        data !== undefined
                        ?  (
                        <DataTable 
                            columns={col}
                            data={data}
                            showPagination={true}
                            // handleServerSidePagination={handleServerSidePagination}
                            // pageProperty={{ totalPages}}
                        />):(
                            <div className="alignCenter">
                                <Spinner animation="border" />
                            </div>
                        )
                    }
                </div>
            </div>

        </div>
    )
}
export default ChannelList;
