import React from 'react';
import {
    Card,
    Container,
} from 'react-bootstrap';
import InputText from '../../components/Global/Input/InputText';
import Switch from '../../components/Global/Switch/Switch';
import DetailsLabel from './DetailsLabel';


function ViewGatewayDetails(props){
    const {
        values: { code, description, name, status },
        handleChange, setFieldValue, gatewayTypeDetails
    } = props;

    const handleSwitchChange = ( value ) => {
        setFieldValue('status',value ? 'active': 'inactive');
    }
    
    return(
        <Card>
            <Card.Body>
                <div className="cardHeader">
                    <Card.Title className="cardTitle">Gateway Details</Card.Title>
                </div>
                <Card.Text>
                    <Container>
                        <DetailsLabel 
                            labelClassName="bodyRowLabel" 
                            labelName="Code" 
                            valueName={<InputText name="code" value={code} className="feildLabel disabled" disabled/>}
                            valueClassName="bodyRowValue"
                            rowClassName="rowMargin"
                        />
                        <DetailsLabel 
                            labelClassName="bodyRowLabel" 
                            labelName="Name" 
                            valueName={<InputText 
                                name="name"
                                value={name}
                                onChange={(e) => {
                                    handleChange(e)
                                    gatewayTypeDetails["name"] = e.target.value;
                                }} 
                                className="feildLabel" 
                            />}
                            valueClassName="bodyRowValue"
                            rowClassName="rowMargin"
                        />
                        <DetailsLabel 
                            labelClassName="bodyRowLabel" 
                            labelName="Description" 
                            valueName={
                                <InputText 
                                    name="description" 
                                    as="textarea" 
                                    value={description} 
                                    rows={3} 
                                    onChange={(e) => {
                                        handleChange(e)
                                        gatewayTypeDetails["description"] = e.target.value;
                                    }} 
                                    className="textAreaLabel"
                                />}
                            valueClassName="bodyRowValue"
                            rowClassName="rowMargin"
                        />
                        <DetailsLabel 
                            labelClassName="bodyRowLabel" 
                            labelName="Status" 
                            valueName={
                                <div className="detailsActive">
                                    <Switch 
                                        type="switch" 
                                        id={code}
                                        name="status" 
                                        defaultChecked={status === "active"} 
                                        onChange={(e) => {
                                            gatewayTypeDetails["status"] = e.target.checked;
                                            handleSwitchChange(e.target.checked)}
                                        }
                                    /> 
                                    <div>{status === "active" ? 'Active' : 'Inactive'}</div>
                                </div>
                            }
                            valueClassName="bodyRowValue"
                            rowClassName="rowMargin"
                        />
                    </Container>
                </Card.Text>
            </Card.Body>
        </Card>
    )
}

export default ViewGatewayDetails;
