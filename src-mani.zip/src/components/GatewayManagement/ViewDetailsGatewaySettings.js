import React ,{ useState} from 'react';
import { 
    Row, Button, Col,
    Image, Spinner 
} from 'react-bootstrap';
import { useHistory } from 'react-router';
import SearchBar from '../Global/SearchBar/SearchBar';
import DataTable from '../Global/DataTable/DataTable';
import EditIcon from '../../assets/icons/icon-edit-outline.svg';
import DeleteIcon from '../../assets/icons/icon-delete.svg';
import Switch from '../Global/Switch/Switch';
import { Link } from 'react-router-dom';

const editIcon = (<Image src={EditIcon} className="icon"/>);
const actionDiv = ( ele, handleStatusChange, history ) => (
    <div className="actionDiv" key={`action_${ele.code}`}>
        <Switch
                type="switch"
                id={`custom-switch-${ele.code}`}
                defaultChecked={ele.status === 'active'}
                onChange={(e) => handleStatusChange(e.target.checked, ele.code)}
            />
        <div className="editDiv" onClick={() => history.push(`/gatewaymanagment/gatewaySettings/${ele.code}`)}>{editIcon}</div>
        <div className="deleteDiv">
            <Image src={DeleteIcon} className="icon" />
        </div>
    </div>
);

const sortByElement = ( rowA, rowB, colId, desc) => {
    const findFn = ( entry ) => entry.column && (entry.column.id ===  colId)
    const foundAData = rowA.cells.find(findFn);
    const foundBData = rowB.cells.find(findFn);
    const aValue =  typeof rowA.cells[0] !== "function" && foundAData && foundAData.value.props.children;
    const bValue =  typeof rowB.cells[0] !== "function" && foundBData && foundBData.value.props.children;
    return alphaNumericSorting( aValue, bValue, colId, desc)
}

const alphaNumericSorting = (frstValue, scndValue, colId, desc=false) => {
    if( frstValue && scndValue ){
        if( !desc ) return frstValue.localeCompare(scndValue)
        return (-1 *(scndValue.localeCompare(frstValue)))
    }
}

const statusDiv = (data) => {
    const { status } = data;
    let stat = 'Disabled';
    let className = 'status_disabled';
    if ( status === 'active' ) {
        stat = 'Enabled';
        className = 'status_enabled';
    }
    return (
        <div className={className}>{stat}</div>
    )
}
const codeDiv = (data, idx) => (
    <Link 
        className="modalLink"
        to={{ 
            pathname: `/gatewaymanagment/gatewaySettings/${data.code}`, 
            state: { storage: "local", idx },
        }}
    >
        {data.code}
    </Link>
)

function ViewDetailsGatewaySettings(props) {
    const { gatewaySettingsList , isdelete, iscreate, isupdate} = props;
    let [ activeRow, setActiveRow] = useState([]);
    const history = useHistory();
    const handleSettings = (values) => console.log('add setting', values)
    const addSettings = () => history.push({ pathname: "/gatewaymanagment/gatewaySettings/add", state : { storage: "local" }});
    let [ settingData= gatewaySettingsList, setSettingData ] = useState();
    const  handleClick = ( category, ipText ) => {
        const condtnFn = (ele) => {
            if(ele[(category)] && isNaN(ele[(category)])) {
              if( ele[(category)].toLowerCase().includes(ipText.toLowerCase())) return true
            }
            else if ( ele[(category)] && ele[(category)] === parseInt(ipText)) return true;
            return false;
        }
        const categoryFilterdData = [ ...gatewaySettingsList ].filter(condtnFn);
        setSettingData(categoryFilterdData );
    }

    const handleStatusChange = ( value, code ) => {
        const finder = gatewaySettingsList.find(( ele ) => ele.code === code);
        finder["status"] = value?"active": "inactive";
        setSettingData([...gatewaySettingsList]);
    }

    const handleHeaderCheck = ( value ) => {
        if( value) setActiveRow( [...gatewaySettingsList.map((entry) => entry.code)]);
        else setActiveRow([]);
    }

    let columns = [
        {
            Header: (
                <Switch
                    onClick={(e) => handleHeaderCheck(e.target.checked)} 
                />
            ),
            accessor: 'checkBox',
            disableSortBy: true
        },
        {
            Header: 'Code',
            accessor: 'code',
            selector: 'code',
            sortType: ( rowA, rowB, colId, desc ) => {
                return sortByElement(rowA, rowB, colId, desc)
            }
        },
        {
            Header: 'Name',
            accessor: 'name',
        },
        {
            Header: 'Value',
            accessor: 'value'
        },
        {
            Header: 'Status',
            accessor: 'status',
            sortType: ( rowA, rowB, colId, desc ) => {
                return sortByElement(rowA, rowB, colId, desc)
            }
        }
    ];

    
    const handleCheckList = ( value, code ) => {
        const idx = activeRow.indexOf( code );
        if( value) setActiveRow( [...activeRow, code ] );
        else {
            activeRow.splice( idx, 1);
            setActiveRow([...activeRow])
        }
    }

    const localObj = settingData && settingData.map((ele, idx) => {
        return {
            ...ele, code: codeDiv(ele, idx), status: statusDiv(ele), action : actionDiv(ele, handleStatusChange, history),
            checkBox: (
                <Switch
                    onChange={(e) => handleCheckList(e.target.checked, ele.code)} 
                    checked={activeRow.indexOf(ele.code) !== -1}
                />
            ),
            className: activeRow && activeRow.find((itr) => itr === ele.code)? 'activeRow' :''
        }
    });
    
    const isEnabled = settingData && activeRow.length !== 0 && ( [ ...settingData.filter((ele ) => activeRow.includes(ele.code))].filter(ele => ele.status === 'active').length === activeRow.length);
    const isDisabled = settingData && activeRow.length !== 0  && ( [ ...settingData.filter((ele ) => activeRow.includes(ele.code))].filter(ele => ele.status === 'inactive').length === activeRow.length);
    let btnText = '';
    if ( isEnabled ) {
        btnText = 'Disable';
    }  else if ( isDisabled ) {
        btnText = 'Enable';  
    } else if( isupdate ) {
        columns = [
            ...columns,
            {
                Header: 'Actions',
                accessor: 'action',
                disableSortBy: true,
                className: 'actionCol'
            },
        ];
    }
    const categoryList = [
        {'key': 'Code', 'value': 'code'},
        {'key': 'Name', 'value': 'name'},
        {'key': 'Value', 'value': 'value'},
        {'key': 'Status', 'value': 'status'},
    ]
    return(
        <div className="gatewaySettings">
            <div className="searchCard">
                <Row className="mb10">
                    <Col sm={8}>
                        <b>Gateway Settings</b>
                    </Col>
                    <Col className="alignRight">
                        {iscreate && (
                            <Button variant="secondary" onClick={() => addSettings()} >
                                Add Gateway Settings
                            </Button>
                        )}
                    </Col>
                </Row>
                <SearchBar categoryList={categoryList} textPlaceHolder="Input setting code" handleClick={handleClick}/>
                <div className="btnBlock">
                    {
                        (activeRow.length > 0) 
                        ? (
                            <>
                                {btnText && <Button variant="primary" className="mr5">{btnText} </Button>}
                                {isdelete && <Button variant="primary" className="danger">Delete</Button>}
                                <span className="highlighter">{activeRow.length} items selected</span>
                            </>
                        ) : ''
                    }
                </div>
                <div className="dataBlock">
                    {
                        localObj !== undefined
                        ?  (
                        <DataTable 
                            columns={columns}
                            data={localObj}
                            showPagination={true}
                            defaultPageSize={5}
                        />):(
                            <div className="alignCenter">
                                <Spinner animation="border" />
                            </div>
                        )
                    }
                </div>
            </div>
        </div>
    )
}

export default ViewDetailsGatewaySettings;
