import React, { useEffect, useState } from "react";
import {
  Col,
  Form,
  Row,
  Card,
  Image,
  Spinner,
} from 'react-bootstrap';
import { useDispatch, useSelector } from "react-redux";
import { useHistory  } from 'react-router-dom';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import backIcon from '../../assets/icons/backIcon.png'
import BDOButton from '../Global/Button/BDOButton';
import ConfirmationModal from '../Global/ConfirmationModal/ConfirmationModal';
import InputText from '../Global/Input/InputText';
import Switch from '../Global/Switch/Switch';
import { retrieveCCMRecord ,updateCCMStatus }  from '../../actions/ccmparameter';
let initialValues = {};
let dataToBeEdited = {};

const renderError = ( formik, paramname) => (
  formik.errors[(paramname)]? (
    <span className='mb-1 error-text'>
      {formik.errors.paramname}
    </span>
  ) : null
)

const getClassName = (formik, paramname) => {
  let returnMsg = "input-text";
  if( formik.errors[(paramname)]) return returnMsg+" error"
  return returnMsg
}

export default function AddCCMParameter(props) {
  const history = useHistory();
  const confirmHandler = ( values ) => {
    history.push({pathname: '/ccmparameter', state: {values}})
  }
  const dispatch = useDispatch();

  let propsData = props?.location?.state;
  let retrivedData = useSelector( state => state.ccmparameter);

    useEffect(() => {
      if(propsData.toggleaction === 'EDIT'){
      dispatch(retrieveCCMRecord(propsData.datatochild.code));     
      }      
  }, []);
  const [ openConfirmModal, setConfirmModal ] = useState(false);
  const [ resultValue, setResultValue ] = useState({});
  dataToBeEdited = retrivedData?.viewCcmParameter?.data?.ccmParameterDetails;
   
  const categoryList = [
    {'key': 'Gateway Code', 'value': 'code'},
    {'key': 'Gateway Name', 'value': 'name'},
    {'key': 'Gateway Description', 'value': 'description'},
    {'key': 'Status', 'value': 'status'},
  ];
  
  if (propsData && propsData.datatochild && dataToBeEdited !== undefined ) {
    let info = propsData.datatochild;
    let dataToEdit = dataToBeEdited; 
    initialValues.paramcode = info.code || '';
    initialValues.paramname = dataToEdit.name || '';
    initialValues.paramvalue = dataToEdit.value || '';
    initialValues.paramdescription = dataToEdit.description ||'';
    initialValues.datatype = dataToEdit.dataType || '';
    initialValues.fielddefaultvalue = dataToEdit.defaultValue || '';
    initialValues.maximumvalue = dataToEdit.maximumValue || '';
    initialValues.minimumvalue = dataToEdit.minimumValue || '';
    initialValues.status = dataToEdit?.status;
    initialValues.required=dataToEdit.required;
    initialValues.affectedmodules = dataToEdit.affectedModule ? dataToEdit.affectedModule : '';
  }
  const formik = useFormik({
    enableReinitialize: true, 
    initialValues,
    validationSchema: Yup.object({
        paramcode: Yup.string()
          .max(10, 'Must be 10 characters or less')
          .required('Required'),
        paramname: Yup.string()
          .matches(/^[A-Za-z ]*$/, 'Please enter valid name')
          .max(50, 'Must be 50 characters or less')
          .required('Required'),
        paramvalue: Yup.string()
          .required('Required'),
        paramdescription: Yup.string()
          .max(200, 'Must be 200 characters or less')
          .required('Required'),
        datatype: Yup.string().required('Required'),
        fielddefaultvalue: Yup.string()
          .max(50, 'Must be 50 characters or less')
          .required('Required'),
        maximumvalue:Yup.number()
          .typeError("That doesn't look like a number")
          .positive("Number can't be negative")
          .max(50, 'Must be 50 characters or less')
          .integer("Number can't include a decimal point")
          .required('Required'),
        minimumvalue: Yup.number()
          .typeError("That doesn't look like a number")
          .positive("Number can't be negative")
          .max(50, 'Must be 50 characters or less')
          .integer("Number can't include a decimal point")
          .required('Required'),
        affectedmodules: Yup.string()
          .max(200, 'Must be 200 characters or less')
          .required('Required'),
        reason: Yup.string().required('Required'),
        required: Yup.string().required('Required'),
        status: Yup.string().required('Required')
    }),
    onSubmit: values => {
      console.log(values);
      dispatch(updateCCMStatus(values, (respData) => {
        const { data } = respData;
        
      console.log(data)
      history.push({pathname: '/ccmparameter', state: {data}})
      }));
    },
  });
  const handleSwitchChange = (  name,value ) => {
    if(name === "status"){
      formik.setFieldValue(name, value ? 'active': 'inactive');
    } else {
      formik.setFieldValue(name, value);
    }
  }
  function goBack() {
    formik.resetForm();
    initialValues={};
    retrivedData={};
		history.push("/ccmparameter");
  }
  let title = propsData?.toggleaction?.toLowerCase();
  title = title[0]?.toUpperCase() + title.substring(1, title.length);
  return (
    <div className="addCcm mt-2">
      <div className="headertitle">
        <Image  onClick={goBack} src={backIcon}  className="icon"/>
        <b>{`${title}  CCM Parameter`}</b>
      </div>
      {
        openConfirmModal && (
          <ConfirmationModal 
            openState={openConfirmModal}
            confirmHandler={confirmHandler}
            cancelHandler={goBack}
            headerText={"Add CCM Parameter"}
            bodyContent={"Do you want to add ccm parameter ?."}
            contentObj={resultValue}
            des
            modalSize={"lg"}
          />
        ) 
      }
      <Form  onSubmit={formik.handleSubmit}>
        {(propsData?.toggleaction === 'ADD' || (propsData?.toggleaction === 'EDIT')) ?
          (
            <Card className="cardbodystyle border-0">
               <Card.Body >
                <Row  className="mt-2 mr-2 ml-2">
                  <Col xs='2' sm='2' >
                    <div className=''>
                      <label htmlFor='paramcode' className=''>Parameter Code </label>
                          
                    </div>
                  </Col>
                  <Col xs='5' sm='5'>
                    <InputText 
                      className={getClassName(formik, 'paramcode')}
                      value={formik.values.paramcode}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      disabled={propsData.toggleaction==="EDIT"}
                      name='paramcode'
                      placeholder='Enter parameter code'
                    />
                    {renderError(formik, 'paramcode')}
                  </Col>
              </Row>
              <Row className="mt-2 mr-2 ml-2">
                <Col xs='2' sm='2' >
                  <div className=''>
                    <label htmlFor='paramname' className=''>Parameter Name </label>
                        
                  </div>
                </Col>
                 <Col xs='5' sm='5'>
                    <InputText
                      className={getClassName(formik, 'paramname')}
                      value={formik.values.paramname}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      name='paramname'
                      placeholder='Enter parameter name'
                    />
                    {renderError(formik, 'paramname')}
                  </Col>
              </Row>
              <Row  className="mt-2 mr-2 ml-2">
                <Col xs='2' sm='2' >
                  <div className=''>
                    <label htmlFor='paramvalue' className=''>Parameter Value </label>
                  </div>
                </Col>
                 <Col xs='5' sm='5'>
                    <InputText
                      className={getClassName(formik, 'paramvalue')}
                      value={formik.values.paramvalue}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      name='paramvalue'
                      placeholder='Enter parameter value'
                    />
                    {renderError(formik, 'paramvalue')}
                  </Col>
              </Row>
              <Row  className="mt-2 mr-2 ml-2">
                <Col xs='2' sm='2' >
                  <div className=''>
                    <label htmlFor='paramdescription' className=''>Parameter Description </label>
                  </div>
                </Col>
                <Col xs='5' sm='5'>
                  <InputText
                    as="textarea"
                    rows={3}
                    className={getClassName(formik, 'paramdescription')}
                    value={formik.values.paramdescription}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    name='paramdescription'
                    placeholder='Enter parameter description'
                  />
                  {renderError(formik, 'paramdescription')} 
                  </Col>
              </Row>
              <Row  className="mt-2 mr-2 ml-2">
                <Col xs='2' sm='2' >
                  <div className=''>
                    <label htmlFor='paramdescription' className=''>Data Type </label>
                  </div>
                </Col>
                <Col xs='5' sm='5'>
                 <select
                    name="datatype"
                    className={`form-control  ${getClassName(formik, 'datatype')}`}
                    value={formik.values.datatype}
                    onChange={formik.handleChange}
                  >
                    <option value="">Select datatype</option>
                    {categoryList.map((item, i) => (
                        <option value={item.value} key={i}>{item.key}</option>
                    ))}
                  </select>
                  {renderError(formik, 'datatype')}
                </Col>
              </Row>
              <Row  className="mt-2 mr-2 ml-2">
                <Col xs='2' sm='2' >
                  <div className=''>
                    <label htmlFor='reason' className='' >Required </label>
                  </div>
                </Col>
                <Col xs='5' sm='5'>
                  <Switch
                    type="switch"
                    id={`custom-switch-${formik?.values?.paramcode}-required`}
                    onChange={(e) => handleSwitchChange( "required" , e.target.checked)}
                    checked={formik?.values.required}
                  /> 
                  {renderError(formik,'required')}
                </Col>
              </Row>
              <Row  className="mt-2 mr-2 ml-2">
                <Col xs='2' sm='2' >
                  <div className=''>
                    <label htmlFor='fielddefaultvalue' className=''>Field Default Value </label>
                  </div>
                </Col>
                <Col xs='5' sm='5'>
                  <InputText
                    className={getClassName(formik, 'fielddefaultvalue')}
                    value={formik.values.fielddefaultvalue}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    name='fielddefaultvalue'
                    placeholder='Enter default value'
                  />
                  {renderError(formik, 'fielddefaultvalue')}
                </Col>
              </Row>
              <Row  className="mt-2 mr-2 ml-2">
                <Col xs='2' sm='2' >
                  <div className=''>
                    <label htmlFor='minimumvalue' className=''>Minimum Value </label>
                  </div>
                </Col>
                 <Col xs='5' sm='5'>
                    <InputText
                      type="number"
                      className={getClassName(formik, 'minimumvalue')}
                      value={formik.values.minimumvalue}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      name='minimumvalue'
                      placeholder='Enter minimum value'
                    />
                    {renderError(formik, 'minimumvalue')}
                  </Col>
              </Row>
              <Row  className="mt-2 mr-2 ml-2">
                <Col xs='2' sm='2' >
                  <div className=''>
                    <label htmlFor='maximumvalue' className=''>Maximum Value</label>
                  </div>
                </Col>
                 <Col xs='5' sm='5'>
                    <InputText
                      type="number"
                      className={getClassName(formik, 'maximumvalue')}
                      value={formik.values.maximumvalue}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      name='maximumvalue'
                      placeholder='Enter maximum value'
                    />
                    {renderError(formik, 'maximumvalue')}
                  </Col>
              </Row> 
              <Row  className="mt-2 mr-2 ml-2">
                <Col xs='2' sm='2' >
                  <div className=''>
                    <label htmlFor='affectedmodules' className=''>Affected Modules </label>
                  </div>
                </Col>
                <Col xs='5' sm='5'>
                  <InputText
                    className={getClassName(formik, 'affectedmodules')}
                    value={formik.values.affectedmodules}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    name='affectedmodules'
                    placeholder='Enter affected modules'
                  />
                  {renderError(formik, 'affectedmodules')}
                </Col>
              </Row>
              <Row  className="mt-2 mr-2 ml-2">
                <Col xs='2' sm='2' >
                  <div className=''>
                    <label htmlFor='reason' className=''>Status</label>
                  </div>
                </Col>
                <Col xs='5' sm='5'>
                  <Switch
                    type="switch"
                    id={`custom-switch-${formik?.values?.paramcode}`}
                    onChange={(e) => handleSwitchChange( "status" , e.target.checked)}
                    checked={formik.values.status === "active"}
                  />
                  {renderError(formik, 'status')}
                </Col>
              </Row>
              <Row  className="mt-2 mr-2 ml-2">
                <Col xs='2' sm='2' >
                  <div className=''>
                    <label htmlFor='reason' className=''>Reason</label>
                  </div>
                </Col>
                 <Col xs='5' sm='5'>
                  <InputText
                    className={getClassName(formik, 'reason')}
                    value={formik.values.reason}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    name='reason'
                    placeholder='Enter reason '
                  />
                  {renderError(formik, 'reason')}
                  </Col>
              </Row>
            </Card.Body>
          </Card>
        ):(
          <div className="alignCenterSpinner">
            <Spinner animation="border" />
          </div>
      )}
      <div className='mt-4 float-right mb8'>
        <BDOButton  onClick={goBack} title="Cancel" style1="style2 mr-3" />
        <BDOButton type="submit" title={propsData?.toggleaction === 'ADD'
            ? 'Add'
            : 'Save'} style1="style1" />
      </div>
    </Form>
  </div>);
}

