import http from "../http-common";

const getAll = () => {
   return http.get("/b/E862");
};

const get = paramsData => {
  return http.get(`/b/DN2D?${paramsData}`);
};

const create = data => {
  return http.post("/posts", data);
};

const update = (id, data) => {
  return http.put(`/posts/${id}`, data);
};

const remove = id => {
  return http.delete(`/posts/${id}`);
};

const removeAll = () => {
  return http.delete(`/posts`);
};

const findByTitle = title => {
  return http.get(`/posts?title=${title}`);
};

const updateCCMStatus = data => {
  return http.get("/b/GZVJ");
}
const CcmService = {
  getAll,
  get,
  create,
  update,
  remove,
  removeAll,
  findByTitle,
  updateCCMStatus
};

export default CcmService;
