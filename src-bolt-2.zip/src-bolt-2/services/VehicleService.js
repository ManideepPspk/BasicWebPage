import http from "../http-common";
import manijson from "../mani.json";

const getAll = () => {
   return http.get("/b/Y5DK");
};

const getList = () => {
  return manijson;
};

const VehicleService = {
  getAll,
  getList,
};

export default VehicleService;
