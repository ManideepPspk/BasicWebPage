/* script file "init_ccm_param_setting_script_v01.sql" */
/* Mondaay 27 March 2022 */
--
-- String  1/1. insert "ccm_allowed_bulk_file_extension" in ccm_param_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from ccm_param_settings where code='ccm_bulk_file_location';
INSERT INTO ccm_param_settings(     
	code,        
	for_approval,
	status,      
	version,     
	name,        
	value,       
	description, 
	reason,      
	updated_user,
	updated_date,
	ccm_params  
)
VALUES 
(
	'ccm_bulk_file_location', 
	'false', 
	'true', 
	0, 
	'ccm_bulk_file_location', 
	'bulk_file\',  
	'S3 Bucket folder for CCM Bulk File Location', 
	'For Testing',
	'backend', 
	current_timestamp, 
		  '{
		  "dataList": [],
		  "dataType": "String",
		  "dataFormat": "#AANNLL",
		  "maximumValue": null,
		  "minimumValue": null,
		  "affectedModules": "ccm",
		  "selectedDataList": null,
		  "fieldDefaultValue": "bulk_file\\"
		  }'
);
--
-- String  2/2. insert "ccm_file_attachment_location" in ccm_param_settings table 
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from ccm_param_settings where code='ccm_file_attachment_location';
INSERT INTO ccm_param_settings(     
	code,        
	for_approval,
	status,      
	version,     
	name,        
	value,       
	description, 
	reason,      
	updated_user,
	updated_date,
	ccm_params  
)
VALUES 
(
	'ccm_file_attachment_location', 
	'false', 
	'true', 
	0, 
	'File Attachment Location', 
	'file_attachment\',  
	'S3 Bucket folder for CCM File Attachment Location', 
	'For Testing', 
	'backend', 
	current_timestamp, 
		  '{
		  "dataList": [],
		  "dataType": "String",
		  "dataFormat": "#AANNLL",
		  "maximumValue": null,
		  "minimumValue": null,
		  "affectedModules": "ccm",
		  "selectedDataList": null,
		  "fieldDefaultValue": "file_attachment\\"
		  }'
);
--
-- String  3/3. insert "ccm_housekeeping_archive_location" in ccm_param_settings table 
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from ccm_param_settings where code='ccm_housekeeping_archive_location';
INSERT INTO ccm_param_settings(     
	code,        
	for_approval,
	status,      
	version,     
	name,        
	value,       
	description, 
	reason,      
	updated_user,
	updated_date,
	ccm_params  
)
VALUES 
(
	'ccm_housekeeping_archive_location', 
	'false', 
	'true', 
	0, 
	'Housekeeping Archive Location', 
	'db_archive\',  
	'S3 Bucket folder for CCM DB Archive', 
	'For Testing', 
	'backend', 
	current_timestamp, 
		  '{
		  "dataList": [],
		  "dataType": "String",
		  "dataFormat": "#AANNLL",
		  "maximumValue": null,
		  "minimumValue": null,
		  "affectedModules": "ccm",
		  "selectedDataList": null,
		  "fieldDefaultValue": "db_archive\\"
		  }'
);
--
-- String  4/4. insert "ccm_message_table_file_location" in ccm_param_settings table 
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from ccm_param_settings where code='ccm_message_table_file_location';
INSERT INTO ccm_param_settings(     
	code,        
	for_approval,
	status,      
	version,     
	name,        
	value,       
	description, 
	reason,      
	updated_user,
	updated_date,
	ccm_params  
)
VALUES 
(
	'ccm_message_table_file_location', 
	'false', 
	'true', 
	0, 
	'Message Table File Location', 
	'db_archive\message',  
	'', 
	'For Testing', 
	'backend', 
	current_timestamp, 
		  '{
		  "dataList": [],
		  "dataType": "String",
		  "dataFormat": "#AANNLL",
		  "maximumValue": null,
		  "minimumValue": null,
		  "affectedModules": "ccm",
		  "selectedDataList": null,
		  "fieldDefaultValue": "db_archive\\message"
		  }'
);
--
-- String  5/5. insert "ccm_message_log_file_location" in ccm_param_settings table 
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from ccm_param_settings where code='ccm_message_log_file_location';
INSERT INTO ccm_param_settings(     
	code,        
	for_approval,
	status,      
	version,     
	name,        
	value,       
	description, 
	reason,      
	updated_user,
	updated_date,
	ccm_params  
)
VALUES 
(
	'ccm_message_log_file_location', 
	'false', 
	'true', 
	0, 
	'Message Log File Location', 
	'db_archive\message_log',  
	'', 
	'For Testing', 
	'backend', 
	current_timestamp, 
		  '{
		  "dataList": [],
		  "dataType": "String",
		  "dataFormat": "#AANNLL",
		  "maximumValue": null,
		  "minimumValue": null,
		  "affectedModules": "ccm",
		  "selectedDataList": null,
		  "fieldDefaultValue": "db_archive\\message_log"
		  }'
);
-- *****************************************************************************
--
-- Integer 6/1. insert "ccm_bdo_application_call_timeout" in ccm_param_settings table 
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from ccm_param_settings where code='ccm_bdo_application_call_timeout';
INSERT INTO ccm_param_settings(     
	code,        
	for_approval,
	status,      
	version,     
	name,        
	value,       
	description, 
	reason,      
	updated_user,
	updated_date,
	ccm_params  
)
VALUES 
(
	'ccm_bdo_application_call_timeout', 
	'false', 
	'true', 
	0, 
	'BDO Application Call Timeout', 
	3,  
	'Indicates the maximum waiting time of CCM in seconds for other BDO Application/Platforms. (ex. MFT, WCM, AD)', 
	'For Testing', 
	'backend', 
	current_timestamp, 
		  '{
		  "dataList": [],
		  "dataType": "Integer",
		  "dataFormat": "NNNNNN",
		  "maximumValue": 10,
		  "minimumValue": 1,
		  "affectedModules": "ccm",
		  "selectedDataList": null,
		  "fieldDefaultValue": "3"
		  }'
);
--
-- Integer 7/2. insert "ccm_external_call_timeout" in ccm_param_settings table 
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from ccm_param_settings where code='ccm_external_call_timeout';
INSERT INTO ccm_param_settings(     
	code,        
	for_approval,
	status,      
	version,     
	name,        
	value,       
	description, 
	reason,      
	updated_user,
	updated_date,
	ccm_params  
)
VALUES 
(
	'ccm_external_call_timeout', 
	'false', 
	'true', 
	0, 
	'External Call Timeout', 
	3,  
	'Indicates the maximum waiting time of CCM in seconds for External Application. (ex. Infobip)', 
	'For Testing', 
	'backend', 
	current_timestamp, 
		  '{
		  "dataList": [],
		  "dataType": "Integer",
		  "dataFormat": "NNNNNN",
		  "maximumValue": 10,
		  "minimumValue": 1,
		  "affectedModules": "ccm",
		  "selectedDataList": null,
		  "fieldDefaultValue": "3"
		  }'
);
/*
--
-- Integer 8/3. insert "ccm_maximum_bulk_file_size" in ccm_param_settings table 
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from ccm_param_settings where code='ccm_maximum_bulk_file_size';
INSERT INTO ccm_param_settings(     
	code,        
	for_approval,
	status,      
	version,     
	name,        
	value,       
	description, 
	reason,      
	updated_user,
	updated_date,
	ccm_params  
)
VALUES 
(
	'ccm_maximum_bulk_file_size', 
	'false', 
	'true', 
	0, 
	'Maximum Bulk File Size', 
	25000,  
	'Maximum size of a single Bulk File (KB)', 
	'For Testing', 
	'backend', 
	current_timestamp, 
		  '{
		  "dataList": [],
		  "dataType": "Integer",
		  "dataFormat": "NNNNNN",
		  "maximumValue": 30000,
		  "minimumValue": 1,
		  "affectedModules": "ccm",
		  "selectedDataList": null,
		  "fieldDefaultValue": "25000"
		  }'
);
*/
--
-- Integer 8/3. insert "ccm_maximum_api_payload_size" in ccm_param_settings table 
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from ccm_param_settings where code='ccm_maximum_api_payload_size';
INSERT INTO ccm_param_settings(     
	code,        
	for_approval,
	status,      
	version,     
	name,        
	value,       
	description, 
	reason,      
	updated_user,
	updated_date,
	ccm_params  
)
VALUES 
(
	'ccm_maximum_api_payload_size', 
	'false', 
	'true', 
	0, 
	'Maximum API Payload Size', 
	2000,  
	'Maximum size of the message request API Payload (KB)', 
	'For Testing', 
	'backend', 
	current_timestamp, 
		  '{
		  "dataList": [],
		  "dataType": "Integer",
		  "dataFormat": "NNNNNN",
		  "maximumValue": 2000,
		  "minimumValue": 1,
		  "affectedModules": "ccm",
		  "selectedDataList": null,
		  "fieldDefaultValue": "2000"
		  }'
);
--
-- Integer 9/4. insert "gatewaycode_maximum_bulk_file_size" in ccm_param_settings table 
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from ccm_param_settings where code='gatewaycode_maximum_bulk_file_size';
INSERT INTO ccm_param_settings(     
	code,        
	for_approval,
	status,      
	version,     
	name,        
	value,       
	description, 
	reason,      
	updated_user,
	updated_date,
	ccm_params  
)
VALUES 
(
	'gatewaycode_maximum_bulk_file_size', 
	'false', 
	'true', 
	0, 
	'Maximum Bulk File Size', 
	20000,  
	'Maximum size of a single Bulk File (KB)', 
	'For Testing', 
	'backend', 
	current_timestamp, 
		  '{
		  "dataList": [],
		  "dataType": "Integer",
		  "dataFormat": "NNNNNN",
		  "maximumValue": 25000,
		  "minimumValue": 1,
		  "affectedModules": "ccm",
		  "selectedDataList": null,
		  "fieldDefaultValue": "20000"
		  }'
);
--
-- Integer 10/5. insert "ccm_maximum_inquiry_request" in ccm_param_settings table 
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from ccm_param_settings where code='ccm_maximum_inquiry_request';
INSERT INTO ccm_param_settings(     
	code,        
	for_approval,
	status,      
	version,     
	name,        
	value,       
	description, 
	reason,      
	updated_user,
	updated_date,
	ccm_params  
)
VALUES 
(
	'ccm_maximum_inquiry_request', 
	'false', 
	'true', 
	0, 
	'Maximum Inquiry Request', 
	10,  
	'Indicates the maximum number of records (reference numbers) that the Channel Application can query in a single inquiry (multiple) message', 
	'For Testing', 
	'backend', 
	current_timestamp, 
		  '{
		  "dataList": [],
		  "dataType": "Integer",
		  "dataFormat": "NNNNNN",
		  "maximumValue": 10,
		  "minimumValue": 1,
		  "affectedModules": "ccm",
		  "selectedDataList": null,
		  "fieldDefaultValue": "10"
		  }'
);
--
-- Integer 11/6. insert "ccm_max_allowed_num_of_gateway_settings_added_per_form" in ccm_param_settings table 
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from ccm_param_settings where code='ccm_max_allowed_num_of_gateway_settings_added_per_form';
INSERT INTO ccm_param_settings(     
	code,        
	for_approval,
	status,      
	version,     
	name,        
	value,       
	description, 
	reason,      
	updated_user,
	updated_date,
	ccm_params  
)
VALUES 
(
	'ccm_max_allowed_num_of_gateway_settings_added_per_form', 
	'false', 
	'true', 
	0, 
	'Max Allowed Num of Gateway Settings Added per Form', 
	5,  
	'Indicates the maximum number of records (reference numbers) that the Channel Application can query in a single inquiry (multiple) message', 
	'For Testing', 
	'backend', 
	current_timestamp, 
		  '{
		  "dataList": [],
		  "dataType": "Integer",
		  "dataFormat": "NNNNNN",
		  "maximumValue": 10,
		  "minimumValue": 1,
		  "affectedModules": "ccm",
		  "selectedDataList": null,
		  "fieldDefaultValue": "5"
		  }'
);
--
-- Integer 12/7. insert "ccm_max_allowed_num_of_gateway_prov_mapped_per_form" in ccm_param_settings table 
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from ccm_param_settings where code='ccm_max_allowed_num_of_gateway_prov_mapped_per_form';
INSERT INTO ccm_param_settings(     
	code,        
	for_approval,
	status,      
	version,     
	name,        
	value,       
	description, 
	reason,      
	updated_user,
	updated_date,
	ccm_params  
)
VALUES 
(
	'ccm_max_allowed_num_of_gateway_prov_mapped_per_form', 
	'false', 
	'true', 
	0, 
	'Max Allowed Num of Gateway Prov Mapped per Form', 
	5,  
	'Maximum allowable number of Gateway Providers Mapped per enroll/ update Gateway form submission', 
	'For Testing', 
	'backend', 
	current_timestamp, 
		  '{
		  "dataList": [],
		  "dataType": "Integer",
		  "dataFormat": "NNNNNN",
		  "maximumValue": 10,
		  "minimumValue": 1,
		  "affectedModules": "ccm",
		  "selectedDataList": null,
		  "fieldDefaultValue": "5"
		  }'
);
--
-- Integer 13/8. insert "ccm_max_num_of_mapped_prov_settings_added_per_form" in ccm_param_settings table 
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from ccm_param_settings where code='ccm_max_num_of_mapped_prov_settings_added_per_form';
INSERT INTO ccm_param_settings(     
	code,        
	for_approval,
	status,      
	version,     
	name,        
	value,       
	description, 
	reason,      
	updated_user,
	updated_date,
	ccm_params  
)
VALUES 
(
	'ccm_max_num_of_mapped_prov_settings_added_per_form', 
	'false', 
	'true', 
	0, 
	'Max Allowed Num of Gateway Settings Added per Form', 
	5,  
	'', 
	'For Testing', 
	'backend', 
	current_timestamp, 
		  '{
		  "dataList": [],
		  "dataType": "Integer",
		  "dataFormat": "NNNNNN",
		  "maximumValue": 10,
		  "minimumValue": 1,
		  "affectedModules": "ccm",
		  "selectedDataList": null,
		  "fieldDefaultValue": "5"
		  }'
);
--
-- Integer 14/9. insert "ccm_message_history_retention" in ccm_param_settings table 
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from ccm_param_settings where code='ccm_message_history_retention';
INSERT INTO ccm_param_settings(     
	code,        
	for_approval,
	status,      
	version,     
	name,        
	value,       
	description, 
	reason,      
	updated_user,
	updated_date,
	ccm_params  
)
VALUES 
(
	'ccm_message_history_retention', 
	'false', 
	'true', 
	0, 
	'Message History retention', 
	90,  
	'Number of days before Message table records are moved to the archive folder', 
	'For Testing', 
	'backend', 
	current_timestamp, 
		  '{
		  "dataList": [],
		  "dataType": "Integer",
		  "dataFormat": "NNNNNN",
		  "maximumValue": 90,
		  "minimumValue": 1,
		  "affectedModules": "ccm",
		  "selectedDataList": null,
		  "fieldDefaultValue": "90"
		  }'
);
--
-- List 15/1. insert "gatewaycode_allowed_bulk_file_extensions" in ccm_param_settings table 
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from ccm_param_settings where code='gatewaycode_allowed_bulk_file_extensions';
INSERT INTO ccm_param_settings(     
	code,        
	for_approval,
	status,      
	version,     
	name,        
	value,       
	description, 
	reason,      
	updated_user,
	updated_date,
	ccm_params  
)
VALUES 
(
	'gatewaycode_allowed_bulk_file_extensions', 
	'false', 
	'true', 
	0, 
	'Allowed Bulk File Extensions', 
	null,  
	'List of allowed extensions of Bulk Files', 
	'For Testing', 
	'backend', 
	current_timestamp, 
		  '{
		  "dataList": [
						"csv"
					  ],
		  "dataType": "List",
		  "dataFormat": null,
		  "maximumValue": null,
		  "minimumValue": null,
		  "affectedModules": "ccm",
		  "selectedDataList": null,
		  "fieldDefaultValue": null
		  }'
);
--
-- Checkbox 16/1. insert "ccm_message_housekeeping_switch" in ccm_param_settings table 
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from ccm_param_settings where code='ccm_message_housekeeping_switch';
INSERT INTO ccm_param_settings(     
	code,        
	for_approval,
	status,      
	version,     
	name,        
	value,       
	description, 
	reason,      
	updated_user,
	updated_date,
	ccm_params  
)
VALUES 
(
	'ccm_message_housekeeping_switch', 
	'false', 
	'true', 
	0, 
	'Message Housekeeping Switch', 
	'Y',  
	'An on and off switch if the Message Table will be included on the application db housekeeping batch job', 
	'For Testing', 
	'backend', 
	current_timestamp, 
	'{
	  "dataList": [],
	  "dataType": "Checkbox",
	  "dataFormat": null,
	  "maximumValue": null,
	  "minimumValue": null,
	  "affectedModules": "ccm",
	  "selectedDataList": null,
	  "fieldDefaultValue": null
	}'
);
--
-- Time 17/1. insert "ccm_broadcast_time_cutoff_start" in ccm_param_settings table 
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from ccm_param_settings where code='ccm_broadcast_time_cutoff_start';
INSERT INTO ccm_param_settings(     
	code,        
	for_approval,
	status,      
	version,     
	name,        
	value,       
	description, 
	reason,      
	updated_user,
	updated_date,
	ccm_params  
)
VALUES 
(
	'ccm_broadcast_time_cutoff_start', 
	'false', 
	'true', 
	0, 
	'Broadcast Time Cutoff Start', 
	'13:00:00',  
	'The window period that P3 messages are not allowed to be sent out. 
    As this will be input in UTC time, please subtract 8 hrs from Philippines time.
    (e.g. 21:00:00 PH time will be 13:00:00 UT)', 
	'For Testing', 
	'backend', 
	current_timestamp, 
	'{
	  "dataList": [],
	  "dataType": "Time",
	  "dataFormat": "HH:MM:SS (UTC)",
	  "maximumValue": null,
	  "minimumValue": null,
	  "affectedModules": "ccm",
	  "selectedDataList": null,
	  "fieldDefaultValue": "13:00:00"
	}'
);
--
-- Time 18/2. insert "ccm_broadcast_time_cutoff_end" in ccm_param_settings table 
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from ccm_param_settings where code='ccm_broadcast_time_cutoff_end';
INSERT INTO ccm_param_settings(     
	code,        
	for_approval,
	status,      
	version,     
	name,        
	value,       
	description, 
	reason,      
	updated_user,
	updated_date,
	ccm_params  
)
VALUES 
(
	'ccm_broadcast_time_cutoff_end', 
	'false', 
	'true', 
	0, 
	'Broadcast Time Cutoff End', 
	'23:00:00',  
	'The window period that P3 messages are not allowed to be sent out. 
    As this will be input in UTC time, please subtract 8 hrs from Philippines time.
    (e.g. 21:00:00 PH time will be 13:00:00 UT)', 
	'For Testing', 
	'backend', 
	current_timestamp, 
	'{
	  "dataList": [],
	  "dataType": "Time",
	  "dataFormat": "HH:MM:SS (UTC)",
	  "maximumValue": null,
	  "minimumValue": null,
	  "affectedModules": "ccm",
	  "selectedDataList": null,
	  "fieldDefaultValue": "23:00:00"
	}'
);