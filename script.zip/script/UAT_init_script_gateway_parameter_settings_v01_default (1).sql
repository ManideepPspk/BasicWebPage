/* script file "init_script_gateway_parameter_settings_v01.sql" */
/* Mondaay 27 March 2022 */
-- GatewayParameterSettings SMS
-- Integer  1/1. insert "sms_maximum_body_character_size" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='sms_maximum_body_character_size';
--
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'sms_maximum_body_character_size',    
	 'Maximum Body Character Size',	
	 'GatewayParameterSettings',      
	 (Select ID from gateway where name='SMS'),        
	 null,
	 null,               
	 1000,             
	 'Maximum body size of the message request
      SMS, Whatsapp, Viber, Voice - value is in number of characters',       
	 false,      
	 true,            
	 'For Testing',            
	 'Backend',    
	 current_timestamp, 
	 null, 
	 '{
	  "dataList": [],
	  "dataType": "integer",
	  "dataFormat": "NNNNNN",
	  "maximumValue": 1000,
	  "minimumValue": 1,
	  "affectedModules": "Gateway",
	  "selectedDataList": null,
	  "fieldDefaultValue": "1000"
	 }'
 );
-- GatewayParameterSettings SMS
-- Integer  2/2. insert "sms_p1_message_validity" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='sms_p1_message_validity';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'sms_p1_message_validity',    
	 'P1 Message Validity',	
	 'GatewayParameterSettings',      
	 (Select ID from gateway where name='SMS'),        
	 null,
	 null,               
	 60,             
	 'Message Validity period for P1 Messages (e.g. 1 min)',       
	 false,      
	 true,            
	 'For Testing',            
	 'Backend',    
	 current_timestamp, 
	 null, 
	 '{
	  "dataList": [],
	  "dataType": "integer",
	  "dataFormat": "NNNNNN",
	  "maximumValue": 60,
	  "minimumValue": 1,
	  "affectedModules": "Gateway",
	  "selectedDataList": null,
	  "fieldDefaultValue": "60"
	 }'
 );
-- GatewayParameterSettings SMS
-- Integer  3/3. insert "sms_p2_message_validity" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='sms_p2_message_validity';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'sms_p2_message_validity',    
	 'P2 Message Validity',	
	 'GatewayParameterSettings',      
	 (Select ID from gateway where name='SMS'),        
	 null,
	 null,               
	 120,             
	 'Message Validity period for P2 Messages (e.g. 1 min)',       
	 false,      
	 true,            
	 'For Testing',            
	 'Backend',    
	 current_timestamp, 
	 null, 
	 '{
	  "dataList": [],
	  "dataType": "integer",
	  "dataFormat": "NNNNNN",
	  "maximumValue": 120,
	  "minimumValue": 1,
	  "affectedModules": "Gateway",
	  "selectedDataList": null,
	  "fieldDefaultValue": "120"
	 }'
 );
-- GatewayParameterSettings SMS
-- Integer  4/4. insert "sms_p3_message_validity" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='sms_p3_message_validity';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'sms_p3_message_validity',    
	 'P3 Message Validity',	
	 'GatewayParameterSettings',      
	 (Select ID from gateway where name='SMS'),        
	 null,
	 null,               
	 240,             
	 'Message Validity period for P3 Messages (e.g. 1 min)',       
	 false,      
	 true,            
	 'For Testing',            
	 'Backend',    
	 current_timestamp, 
	 null, 
	 '{
	  "dataList": [],
	  "dataType": "integer",
	  "dataFormat": "NNNNNN",
	  "maximumValue": 240,
	  "minimumValue": 1,
	  "affectedModules": "Gateway",
	  "selectedDataList": null,
	  "fieldDefaultValue": "240"
	 }'
 );
-- GatewayParameterSettings SMS
-- Integer  5/5. insert "sms_channel_maximum_rejection_rate" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='sms_channel_maximum_rejection_rate';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'sms_channel_maximum_rejection_rate',    
	 'Channel Maximum Rejection Rate',	
	 'GatewayParameterSettings',      
	 (Select ID from gateway where name='SMS'),        
	 null,
	 null,               
	 5,             
	 'Maximum percentage of rejected emails per channel in the gateway per day.
Percentage depends on the count of rejected emails of the channel versus the overall count of messages sent by channel to the gateway. Ex. 2%',       
	 false,      
	 true,            
	 'For Testing',            
	 'Backend',    
	 current_timestamp, 
	 null, 
	 '{
	  "dataList": [],
	  "dataType": "integer",
	  "dataFormat": "NNNNNN",
	  "maximumValue": 50,
	  "minimumValue": 1,
	  "affectedModules": "Gateway",
	  "selectedDataList": null,
	  "fieldDefaultValue": "5"
	 }'
 );
-- GatewayParameterSettings SMS
-- Integer  6/6. insert "sms_channel_threshold_for_rejection_rate" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='sms_channel_threshold_for_rejection_rate';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'sms_channel_threshold_for_rejection_rate',    
	 'Channel Threshold for Rejection Rate',	
	 'GatewayParameterSettings',      
	 (Select ID from gateway where name='SMS'),        
	 null,
	 null,               
	 3,             
	 'Threshold of the maximum percentage of rejected emails per channel in the gateway per day.
      Percentage depends on the count of rejected emails from customers versus the overall count of messages sent to the gateway. Ex. 1%',       
	 false,      
	 true,            
	 'For Testing',            
	 'Backend',    
	 current_timestamp, 
	 null, 
	 '{
	  "dataList": [],
	  "dataType": "integer",
	  "dataFormat": "NNNNNN",
	  "maximumValue": 30,
	  "minimumValue": 1,
	  "affectedModules": "Gateway",
	  "selectedDataList": null,
	  "fieldDefaultValue": "3"
	 }'
 );
-- GatewayParameterSettings SMS
-- List  7/7. insert "sms_channel_rejection_error_code_computation" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='sms_channel_rejection_error_code_computation';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'sms_channel_rejection_error_code_computation',    
	 'Channel Rejection Error Code Computation',	
	 'GatewayParameterSettings',      
	 (Select ID from gateway where name='SMS'),        
	 null,
	 null,               
	 null,             
	 'List of error codes to consider for computation of the Channel Rejection Rate. Channel Rejection is based on CCM error codes',       
	 false,      
	 true,            
	 'For Testing',            
	 'Backend',    
	 current_timestamp, 
	 null, 
		'{
		  "dataList": [
					   "CCM-GEN-ERR-0001",
					   "CCM-GEN-ERR-0002",
					   "CCM-GEN-ERR-0003"
					  ],
		  "dataType": "list",
		  "dataFormat": null,
		  "maximumValue": null,
		  "minimumValue": null,
		  "affectedModules": "Gateway",
		  "selectedDataList": null,
		  "fieldDefaultValue": null
		}'
 );
-- GatewayParameterSettings eMail
-- List  8/8. insert "email_allowed_file_attachment_extensions" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='email_allowed_file_attachment_extensions';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'email_allowed_file_attachment_extensions',    
	 'Allowed File Attachment Extensions',	
	 'GatewayParameterSettings',      
	 (Select ID from gateway where name='EMAIL'),        
	 null,
	 null,               
	 null,             
	 'List of allowed extensions of file attachments',       
	 false,      
	 true,            
	 'For Testing',            
	 'Backend',    
	 current_timestamp, 
	 null, 
		'{
		  "dataList": [
					   "csv",
					   "pdf",
					   "xls"
					  ],
		  "dataType": "list",
		  "dataFormat": null,
		  "maximumValue": null,
		  "minimumValue": null,
		  "affectedModules": "Gateway",
		  "selectedDataList": null,
		  "fieldDefaultValue": null
		}'
 );
-- GatewayParameterSettings eMail
-- Integer  9/9. insert "email_maximum_file_attachment_size" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='email_maximum_file_attachment_size';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'email_maximum_file_attachment_size',    
	 'Maximum File Attachment Size',	
	 'GatewayParameterSettings',      
	 (Select ID from gateway where name='EMAIL'),        
	 null,
	 null,               
	 1500,             
	 'Maximum file attachment size of individual and collective files in 1 request
      e.g. 25000KB',       
	 false,      
	 true,            
	 'For Testing',            
	 'Backend',    
	 current_timestamp, 
	 null, 
	 '{
	  "dataList": [],
	  "dataType": "integer",
	  "dataFormat": "NNNNNN",
	  "maximumValue": 1500,
	  "minimumValue": 1,
	  "affectedModules": "Gateway",
	  "selectedDataList": null,
	  "fieldDefaultValue": "1500"
	 }'
 );
-- GatewayParameterSettings eMail
-- Integer  10/10. insert "email_maximum_subject_length" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='email_maximum_subject_length';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'email_maximum_subject_length',    
	 'Maximum Subject Length',	
	 'GatewayParameterSettings',      
	 (Select ID from gateway where name='EMAIL'),        
	 null,
	 null,               
	 500,             
	 'Indicates the maximum length of a subject per email message. (per char)',       
	 false,      
	 true,            
	 'For Testing',            
	 'Backend',    
	 current_timestamp, 
	 null, 
	 '{
	  "dataList": [],
	  "dataType": "integer",
	  "dataFormat": "NNNNNN",
	  "maximumValue": 500,
	  "minimumValue": 100,
	  "affectedModules": "Gateway",
	  "selectedDataList": null,
	  "fieldDefaultValue": "500"
	 }'
 );
-- GatewayParameterSettings eMail
-- Integer  11/11. insert "email_maximum_body_size" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='email_maximum_body_size';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'email_maximum_body_size',    
	 'Maximum Body Size',	
	 'GatewayParameterSettings',      
	 (Select ID from gateway where name='EMAIL'),        
	 null,
	 null,               
	 1700,             
	 'Maximum body size of the message request
      Email - value is in KB',       
	 false,      
	 true,            
	 'For Testing',            
	 'Backend',    
	 current_timestamp, 
	 null, 
	 '{
	  "dataList": [],
	  "dataType": "integer",
	  "dataFormat": "NNNNNN",
	  "maximumValue": 1700,
	  "minimumValue": 1,
	  "affectedModules": "Gateway",
	  "selectedDataList": null,
	  "fieldDefaultValue": "1700"
	 }'
 );
-- GatewayParameterSettings EMAIL
-- Integer  12/12. insert "email_p1_message_validity" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='email_p1_message_validity';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'email_p1_message_validity',    
	 'P1 Message Validity',	
	 'GatewayParameterSettings',      
	 (Select ID from gateway where name='EMAIL'),        
	 null,
	 null,               
	 60,             
	 'Message Validity period for P1 Messages (e.g. 1 min)',       
	 false,      
	 true,            
	 'For Testing',            
	 'Backend',    
	 current_timestamp, 
	 null, 
	 '{
	  "dataList": [],
	  "dataType": "integer",
	  "dataFormat": "NNNNNN",
	  "maximumValue": 60,
	  "minimumValue": 1,
	  "affectedModules": "Gateway",
	  "selectedDataList": null,
	  "fieldDefaultValue": "60"
	 }'
 );
-- GatewayParameterSettings EMAIL
-- Integer  13/13. insert "email_p2_message_validity" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='email_p2_message_validity';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'email_p2_message_validity',    
	 'P2 Message Validity',	
	 'GatewayParameterSettings',      
	 (Select ID from gateway where name='EMAIL'),        
	 null,
	 null,               
	 120,             
	 'Message Validity period for P2 Messages (e.g. 1 min)',       
	 false,      
	 true,            
	 'For Testing',            
	 'Backend',    
	 current_timestamp, 
	 null, 
	 '{
	  "dataList": [],
	  "dataType": "integer",
	  "dataFormat": "NNNNNN",
	  "maximumValue": 120,
	  "minimumValue": 1,
	  "affectedModules": "Gateway",
	  "selectedDataList": null,
	  "fieldDefaultValue": "120"
	 }'
 );
-- GatewayParameterSettings EMAIL
-- Integer  14/14. insert "email_p3_message_validity" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='email_p3_message_validity';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'email_p3_message_validity',    
	 'P3 Message Validity',	
	 'GatewayParameterSettings',      
	 (Select ID from gateway where name='EMAIL'),        
	 null,
	 null,               
	 240,             
	 'Message Validity period for P3 Messages (e.g. 1 min)',       
	 false,      
	 true,            
	 'For Testing',            
	 'Backend',    
	 current_timestamp, 
	 null, 
	 '{
	  "dataList": [],
	  "dataType": "integer",
	  "dataFormat": "NNNNNN",
	  "maximumValue": 240,
	  "minimumValue": 1,
	  "affectedModules": "Gateway",
	  "selectedDataList": null,
	  "fieldDefaultValue": "240"
	 }'
 );
-- GatewayParameterSettings EMAIL
-- Integer  15/15. insert "email_maximum_message_size" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='email_maximum_message_size';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'email_maximum_message_size ',    
	 'Maximum Message Size',	
	 'GatewayParameterSettings',      
	 (Select ID from gateway where name='EMAIL'),        
	 null,
	 null,               
	 2000,             
	 'Maximum size of the entire message to be sent to the client after data enrichment. Includes file attachments. (KB)',       
	 false,      
	 true,            
	 'For Testing',            
	 'Backend',    
	 current_timestamp, 
	 null, 
	 '{
	  "dataList": [],
	  "dataType": "integer",
	  "dataFormat": "NNNNNN",
	  "maximumValue": 2500,
	  "minimumValue": 1,
	  "affectedModules": "Gateway",
	  "selectedDataList": null,
	  "fieldDefaultValue": "2000"
	 }'
 );
-- GatewayParameterSettings EMAIL
-- Integer  16/16. insert "email_channel_maximum_rejection_rate" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='email_channel_maximum_rejection_rate';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'email_channel_maximum_rejection_rate',    
	 'Channel Maximum Rejection Rate',	
	 'GatewayParameterSettings',      
	 (Select ID from gateway where name='EMAIL'),        
	 null,
	 null,               
	 5,             
	 'Maximum percentage of rejected emails per channel in the gateway per day.
      Percentage depends on the count of rejected emails of the channel versus the overall count of messages sent by channel to the gateway. Ex. 2%',       
	 false,      
	 true,            
	 'For Testing',            
	 'Backend',    
	 current_timestamp, 
	 null, 
	 '{
	  "dataList": [],
	  "dataType": "integer",
	  "dataFormat": "NNNNNN",
	  "maximumValue": 30,
	  "minimumValue": 1,
	  "affectedModules": "Gateway",
	  "selectedDataList": null,
	  "fieldDefaultValue": "5"
	 }'
 );
-- GatewayParameterSettings EMAIL
-- Integer  17/17. insert "email_channel_threshold_for_rejection_rate" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='email_channel_threshold_for_rejection_rate';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'email_channel_threshold_for_rejection_rate',    
	 'Channel Threshold for Rejection Rate',	
	 'GatewayParameterSettings',      
	 (Select ID from gateway where name='EMAIL'),        
	 null,
	 null,               
	 3,             
	 'Threshold of the maximum percentage of rejected emails per channel in the gateway per day.
      Percentage depends on the count of rejected emails from customers versus the overall count of messages sent to the gateway. Ex. 1%',       
	 false,      
	 true,            
	 'For Testing',            
	 'Backend',    
	 current_timestamp, 
	 null, 
	 '{
	  "dataList": [],
	  "dataType": "integer",
	  "dataFormat": "NNNNNN",
	  "maximumValue": 30,
	  "minimumValue": 1,
	  "affectedModules": "Gateway EMAIL",
	  "selectedDataList": null,
	  "fieldDefaultValue": "3"
	 }'
 );
-- GatewayParameterSettings EMAIL
-- List  18/18. insert "email_channel_rejection_error_code_computation" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='email_channel_rejection_error_code_computation';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'email_channel_rejection_error_code_computation',    
	 'Channel Rejection Error Code Computation',	
	 'GatewayParameterSettings',      
	 (Select ID from gateway where name='EMAIL'),        
	 null,
	 null,               
	 null,             
	 'List of error codes to consider for computation of the Channel Rejection Rate. Channel Rejection is based on CCM error codes',       
	 false,      
	 true,            
	 'For Testing',            
	 'Backend',    
	 current_timestamp, 
	 null, 
		'{
		  "dataList": [
					   "CCM-GEN-ERR-0001",
					   "CCM-GEN-ERR-0002",
					   "CCM-GEN-ERR-0003"
					  ],
		  "dataType": "list",
		  "dataFormat": null,
		  "maximumValue": null,
		  "minimumValue": null,
		  "affectedModules": "Gateway",
		  "selectedDataList": null,
		  "fieldDefaultValue": null
	 }'
 );
-- GatewayParameterSettings VIBER
-- Integer  19/19. insert "viber_maximum_body_character_size" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='viber_maximum_body_character_size';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'viber_maximum_body_character_size',    
	 'Maximum Body Character Size',	
	 'GatewayParameterSettings',      
	 (Select ID from gateway where name='VIBER'),        
	 null,
	 null,               
	 1000,             
	 'Maximum body size of the message request
SMS, Whatsapp, Viber, Voice - value is in number of characters',       
	 false,      
	 true,            
	 'For Testing',            
	 'Backend',    
	 current_timestamp, 
	 null, 
		 '{
		  "dataList": [],
		  "dataType": "integer",
		  "dataFormat": "NNNNNN",
		  "maximumValue": 1000,
		  "minimumValue": 1,
		  "affectedModules": "Gateway",
		  "selectedDataList": null,
		  "fieldDefaultValue": "1000"
		 }'
);
-- GatewayParameterSettings VIBER
-- Integer  20/20. insert "viber_p1_message_validity" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='viber_p1_message_validity';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'viber_p1_message_validity',    
	 'P1 Message Validity',	
	 'GatewayParameterSettings',      
	 (Select ID from gateway where name='VIBER'),        
	 null,
	 null,               
	 60,             
	 'Message Validity period for P1 Messages (e.g. 1 min)',       
	 false,      
	 true,            
	 'For Testing',            
	 'Backend',    
	 current_timestamp, 
	 null, 
	 '{
	  "dataList": [],
	  "dataType": "integer",
	  "dataFormat": "NNNNNN",
	  "maximumValue": 60,
	  "minimumValue": 1,
	  "affectedModules": "Gateway",
	  "selectedDataList": null,
	  "fieldDefaultValue": "60"
	 }'
 );
-- GatewayParameterSettings VIBER
-- Integer  21/21. insert "viber_p2_message_validity" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='viber_p2_message_validity';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'viber_p2_message_validity',    
	 'P2 Message Validity',	
	 'GatewayParameterSettings',      
	 (Select ID from gateway where name='VIBER'),        
	 null,
	 null,               
	 120,             
	 'Message Validity period for P2 Messages (e.g. 1 min)',       
	 false,      
	 true,            
	 'For Testing',            
	 'Backend',    
	 current_timestamp, 
	 null, 
	 '{
	  "dataList": [],
	  "dataType": "integer",
	  "dataFormat": "NNNNNN",
	  "maximumValue": 120,
	  "minimumValue": 1,
	  "affectedModules": "Gateway",
	  "selectedDataList": null,
	  "fieldDefaultValue": "120"
	 }'
 );
-- GatewayParameterSettings VIBER
-- Integer  22/22. insert "viber_p3_message_validity" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='viber_p3_message_validity';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'viber_p3_message_validity',    
	 'P3 Message Validity',	
	 'GatewayParameterSettings',      
	 (Select ID from gateway where name='VIBER'),        
	 null,
	 null,               
	 240,             
	 'Message Validity period for P3 Messages (e.g. 1 min)',       
	 false,      
	 true,            
	 'For Testing',            
	 'Backend',    
	 current_timestamp, 
	 null, 
	 '{
	  "dataList": [],
	  "dataType": "integer",
	  "dataFormat": "NNNNNN",
	  "maximumValue": 240,
	  "minimumValue": 1,
	  "affectedModules": "Gateway",
	  "selectedDataList": null,
	  "fieldDefaultValue": "240"
	 }'
 );
-- GatewayParameterSettings VIBER
-- Integer  23/23. insert "viber_channel_maximum_rejection_rate" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='viber_channel_maximum_rejection_rate';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'viber_channel_maximum_rejection_rate',    
	 'Channel Maximum Rejection Rate',	
	 'GatewayParameterSettings',      
	 (Select ID from gateway where name='VIBER'),        
	 null,
	 null,               
	 5,             
	 'Maximum percentage of rejected emails per channel in the gateway per day.
      Percentage depends on the count of rejected emails of the channel versus the overall count of messages sent by channel to the gateway. Ex. 2%',       
	 false,      
	 true,            
	 'For Testing',            
	 'Backend',    
	 current_timestamp, 
	 null, 
	 '{
	  "dataList": [],
	  "dataType": "integer",
	  "dataFormat": "NNNNNN",
	  "maximumValue": 50,
	  "minimumValue": 1,
	  "affectedModules": "Gateway",
	  "selectedDataList": null,
	  "fieldDefaultValue": "5"
	 }'
 );
-- GatewayParameterSettings VIBER
-- Integer  24/24. insert "viber_channel_threshold_for_rejection_rate" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='viber_channel_threshold_for_rejection_rate';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'viber_channel_threshold_for_rejection_rate',    
	 'Channel Threshold for Rejection Rate',	
	 'GatewayParameterSettings',      
	 (Select ID from gateway where name='VIBER'),        
	 null,
	 null,               
	 3,             
	 'Threshold of the maximum percentage of rejected emails per channel in the gateway per day.
      Percentage depends on the count of rejected emails from customers versus the overall count of messages sent to the gateway. Ex. 1%',       
	 false,      
	 true,            
	 'For Testing',            
	 'Backend',    
	 current_timestamp, 
	 null, 
	 '{
	  "dataList": [],
	  "dataType": "integer",
	  "dataFormat": "NNNNNN",
	  "maximumValue": 30,
	  "minimumValue": 1,
	  "affectedModules": "Gateway",
	  "selectedDataList": null,
	  "fieldDefaultValue": "3"
	 }'
 );
-- GatewayParameterSettings VIBER
-- Integer  25/25. insert "viber_channel_rejection_error_code_computation" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='viber_channel_rejection_error_code_computation';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'viber_channel_rejection_error_code_computation',    
	 'Channel Rejection Error Code Computation',	
	 'GatewayParameterSettings',      
	 (Select ID from gateway where name='VIBER'),        
	 null,
	 null,               
	 null,             
	 'List of error codes to consider for computation of the Channel Rejection Rate. Channel Rejection is based on CCM error codes',       
	 false,      
	 true,            
	 'For Testing',            
	 'Backend',    
	 current_timestamp, 
	 null, 
		'{
		  "dataList": [
					   "CCM-GEN-ERR-0001",
					   "CCM-GEN-ERR-0002",
					   "CCM-GEN-ERR-0003"
					  ],
		  "dataType": "list",
		  "dataFormat": null,
		  "maximumValue": null,
		  "minimumValue": null,
		  "affectedModules": "Gateway",
		  "selectedDataList": null,
		  "fieldDefaultValue": null
	 }'
 );
-- GatewayProviderSettings
-- Integer  26/26. insert "infobip_message_validity" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='infobip_message_validity';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'infobip_message_validity',    
	 'Message Validity',	
	 'GatewayProviderSettings',      
 	 null,
 	 null,
	 (Select ID from gw_provider where name='INFOBIP'),        
	 1,             
	 'Minimum validity of the message (e.g. 1 min). P1/2/3 will have the same Gateway Provider Message Validity Period.
      Each Gateway Provider will have its own different message validity period',       
	 false,      
	 true,            
	 'For Testing',            
	 'Backend',    
	 current_timestamp, 
	 null, 
	 '{
	  "dataList": [],
	  "dataType": "integer",
	  "dataFormat": "NNNNNN",
	  "maximumValue": 5,
	  "minimumValue": 1,
	  "affectedModules": "Provider",
	  "selectedDataList": null,
	  "fieldDefaultValue": "1"
	 }'
 );
-- GatewayProviderMappingSettings
-- String  27/27. insert "infobip_sms_context_root" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='infobip_sms_context_root';
DELETE from parameter_settings where code='sms_infobip_context_root';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'sms_infobip_context_root',    
	 'Context Root',	
	 'GatewayProviderMappingSettings',      
 	 null,
	 (select id from gw_prov_mapping where gateway_id in (Select ID from gateway where name in ('SMS')) and gw_provider_id =(select id from gw_provider where name='INFOBIP')),       
	 null,
	 '/sms/2/text/advanced',             
	 'Context root of each Gateway Type is different',       
	 false,      
	 true,            
	 'For Testing',            
	 'Backend',    
	 current_timestamp, 
	 null, 
	 '{
	  "dataList": [],
	  "dataType": "string",
	  "dataFormat": "#AANNLL",
	  "maximumValue": null,
	  "minimumValue": null,
	  "affectedModules": "Provider Mapping",
	  "selectedDataList": null,
	  "fieldDefaultValue": "/sms/2/text/advanced"
	 }'
 );
-- GatewayProviderMappingSettings
-- String  28/28. insert "infobip_email_context_root" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='infobip_email_context_root';
DELETE from parameter_settings where code='email_infobip_context_root';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'email_infobip_context_root',    
	 'Context Root',	
	 'GatewayProviderMappingSettings',      
 	 null,
 	 (select id from gw_prov_mapping where gateway_id in (Select ID from gateway where name in ('EMAIL')) and gw_provider_id =(select id from gw_provider where name='INFOBIP')),       
	 null,
	 '/email/2/send',             
	 'Context root of each Gateway Type is different',       
	 false,      
	 true,            
	 'Provider Mapping',            
	 'Backend',    
	 current_timestamp, 
	 null, 
	 '{
	  "dataList": [],
	  "dataType": "string",
	  "dataFormat": "#AANNLL",
	  "maximumValue": null,
	  "minimumValue": null,
	  "affectedModules": "Provider Mapping",
	  "selectedDataList": null,
	  "fieldDefaultValue": "/email/2/send"
	 }'
 );
-- GatewayProviderMappingSettings
-- String  29/29. insert "infobip_viber_context_root" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='infobip_viber_context_root';
DELETE from parameter_settings where code='viber_infobip_context_root';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'viber_infobip_context_root',    
	 'Context Root',	
	 'GatewayProviderMappingSettings',      
 	 null,
 	 (select id from gw_prov_mapping where gateway_id in (Select ID from gateway where name in ('VIBER')) and gw_provider_id =(select id from gw_provider where name='INFOBIP')),       
	 null,
	 '/omni/1/advanced',             
	 'Context root of each Gateway Type is different',       
	 false,      
	 true,            
	 'Provider Mapping',            
	 'Backend',    
	 current_timestamp, 
	 null, 
	 '{
	  "dataList": [],
	  "dataType": "string",
	  "dataFormat": "#AANNLL",
	  "maximumValue": null,
	  "minimumValue": null,
	  "affectedModules": "Provider Mapping",
	  "selectedDataList": null,
	  "fieldDefaultValue": "/omni/1/advanced"
	 }'
 );
-- GatewayProviderMappingSettings
-- String  30/30. insert "infobip_viber_context_root_scenario" in parameter_settings table
-- Optionally, if parameter exists, we  can enable below Delete statement to Remove it first
DELETE from parameter_settings where code='infobip_viber_context_root_scenario';
DELETE from parameter_settings where code='viber_infobip_context_root_scenario';
INSERT INTO parameter_settings (          
	 code,
	 name, 	 
	 param_entity,      
	 gateway_id,        
	 gw_prov_mapping_id,
	 gw_provider_id,                 
	 value,             
	 description,       
	 for_approval,      
	 status,            
	 reason,            
	 updated_userid,    
	 updated_date, 
	 message_validity, 
	 params
 )
 VALUES
 (
	 'viber_infobip_context_root_scenario',    
	 'Context Root for Scenario Key',	
	 'GatewayProviderMappingSettings',      
 	 null,
 	 (select id from gw_prov_mapping where gateway_id in (Select ID from gateway where name in ('VIBER')) and gw_provider_id =(select id from gw_provider where name='INFOBIP')),       
	 null,
	 '/omni/1/scenarios',             
	 'An additional context root for scenario key is required',       
	 false,      
	 true,            
	 'Provider Mapping',            
	 'Backend',    
	 current_timestamp, 
	 null, 
	 '{
	  "dataList": [],
	  "dataType": "string",
	  "dataFormat": "#AANNLL",
	  "maximumValue": null,
	  "minimumValue": null,
	  "affectedModules": "Provider Mapping",
	  "selectedDataList": null,
	  "fieldDefaultValue": "/omni/1/scenarios"
	 }'
 );