import React from 'react';


function ViewAllVehicles(props) {
  return (
    <>
    <div>Hiiiiii Vehicles here</div>
    </>
  );
}
export default ViewAllVehicles;
