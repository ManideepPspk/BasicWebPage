import { combineReducers } from "redux";
import VehicleReducers from "./VehicleReducers";

export default combineReducers({
  VehicleReducers,
});
