import React from 'react';

import { Switch, Route } from "react-router-dom";
import ViewAllCcmParameter from '../components/CcmParameter/ViewAllCcmParameter';
import AddCCMParameter from '../components/CcmParameter/AddCCMParameter';
import ViewCCMRecord from '../components/CcmParameter/ViewCCMRecord';

function CCMPage(props) {
    return (
        <Switch>
            <Route path={"/ccmparameter/addccmparameter"} component={AddCCMParameter} />
            <Route path={"/ccmparameter/:id"} component={ViewCCMRecord} exact/>
            <Route path={"/"} component={ViewAllCcmParameter} />
        </Switch>
    )
}
export default CCMPage;
