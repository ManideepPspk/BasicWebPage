import { combineReducers } from "redux";
import ccmparameter from "./ccmparameter";
import gatewayReducer from "./gatewaymanagement";
import approvalReducer from "./approval";

export default combineReducers({
  ccmparameter,
  gatewayReducer,
  approvalReducer
});
