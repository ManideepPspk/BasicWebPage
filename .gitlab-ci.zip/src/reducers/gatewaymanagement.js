import {
    VIEW_GATEWAY_TYPE,
    VIEW_ALL_GATEWAY_TYPE,
    VIEW_ALL_GATEWAY_PROVIDER,
    VIEW_GATEWAY_SETIINGS,
    VIEW_GATEWAY_PROVIDERS,
    VIEW_GATEWAY_PROVIDER_SETTING,
    VIEW_ALL_CHANNAL,
  } from "../actions/types";
  
  const initialState = [];
  
  const gatewayReducer = (gateway, action) => {
    if( gateway === undefined) {
      gateway = initialState;
    }
    const { type, payload } = action;
    switch (type) {    
      case VIEW_GATEWAY_TYPE:
        return { ...gateway, "viewGateway": payload } ;      
      case VIEW_ALL_GATEWAY_TYPE:
          return {...gateway,"viewAllGatewayType": payload };
      case VIEW_ALL_GATEWAY_PROVIDER:
          return  {...gateway,"viewAllGatewayProvider": payload };
      case VIEW_GATEWAY_SETIINGS:
          return { ...gateway, "viewGatewaySettings": payload };
      case VIEW_GATEWAY_PROVIDERS:
          return { ...gateway, "viewGatewayProviders": payload };
      case VIEW_GATEWAY_PROVIDER_SETTING:
          return { ...gateway, "viewGatewayProviderSetting": payload };
      case VIEW_ALL_CHANNAL:
          return { ...gateway, "viewAllChannal": payload };
      default:
        return {...gateway};
    }
  };
  export default gatewayReducer;