import React, { useEffect, useRef } from 'react';
import { Image, Button, Form } from 'react-bootstrap';
import ViewGatewayDetails from './ViewGatewayDetails';
import ViewGatewaySubDetails from './ViewGatewaySubDetails';
import { useDispatch, useSelector } from "react-redux";
import { retrieveGatewayRecord } from '../../actions/gatewaymanagement';
import { Link, useHistory } from "react-router-dom";
import backIcon from '../../assets/icons/backIcon.png'
import { Formik } from 'formik';
import './styles/viewGatewayRecord.scss';

function ViewGatewayRecord(props) {
    const history = useHistory();
    const dispatch = useDispatch();
    const retData = useSelector( state => state.gatewayReducer);
    useEffect(() => {
        const { match: {params: { id }} , location: { dataFrom= {}} } = props;
        console.log('dataFrom', dataFrom);
        if( dataFrom !== "localState") dispatch(retrieveGatewayRecord(id))
    }, []);
    const goBack = () => history.push('/gatewaymanagment');
    const { viewGateway={} } = retData;
    console.log('viewGateway', viewGateway);
    const { data= { } } =viewGateway;
    const formikRef = useRef();
    const { gatewayTypeDetails={}, gatewaySettings, gatewayProviderList } = data;
    return(
        <div className="viewLayout-gm">
            <div className="redirect">
                <Link to={"/gatewaymanagment"}>
                    <Image src={backIcon}  className="icon"/>
                </Link>
                <b>{gatewayTypeDetails.code} - {gatewayTypeDetails.name}</b>
            </div>
            <Formik
                initialValues={{...gatewayTypeDetails}}
                enableReinitialize
                onSubmit={(values, action) => {
                    console.log(values);
                }}
                innerRef={formikRef}
            >
            {({ 
                errors, touched, values, handleSubmit, handleChange,
                setFieldValue
            }) => (
                <Form onSubmit={handleSubmit}>
                   <div className="gtwayDetails">
                        { 
                            data &&
                            <ViewGatewayDetails 
                                gatewayTypeDetails={ gatewayTypeDetails}
                                handleChange={handleChange}
                                setFieldValue={setFieldValue}
                                values={values}
                            />
                        }
                    </div>
                </Form>
              )}
            </Formik>
            <div className="subDetails">
                {
                    data &&
                    <ViewGatewaySubDetails
                        gatewaySettingsList={gatewaySettings} 
                        gatewayProviderList={gatewayProviderList}           
                    />
                }
            </div>
            <div className="recordBtnBlock">
                <Button variant="secondary" onClick={() => goBack()}>Cancel</Button>
                <Button variant="primary" onClick={() => formikRef.current.handleSubmit()} >Save</Button>
            </div>    
        </div>
    )
}

export default ViewGatewayRecord;
