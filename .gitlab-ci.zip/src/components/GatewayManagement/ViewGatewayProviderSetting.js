import React, { useState, useEffect } from 'react';
import {
    Col,
    Form,
    Row,
    Card,
    Image,
    Spinner,
    Button,
} from 'react-bootstrap';
import { useDispatch, useSelector } from 'react-redux';
import DetailsLabel from './DetailsLabel';
import { Link, useHistory } from 'react-router-dom';
import './styles/viewGatewaySettings.scss';
import Switch from '../Global/Switch/Switch';
import backIcon from '../../assets/icons/backIcon.png';
import InputText from '../../components/Global/Input/InputText';
import { retrieveGatewayProviderSetting } from '../../actions/gatewaymanagement';
import { useFormik } from 'formik';
import PlusIcon from '../../assets/icons/plus_icon.svg'
import DateTimePicker from '../Global/DateTimePicker/DateTimePicker';
import * as Yup from 'yup';
import BDOButton from '../Global/Button/BDOButton';
import BDOToast from '../../components/Global/BDOToast/BDOToast';
import BDOSelect from "../Global/Select/BDOSelect";
import './styles/viewGatewayRecord.scss';
let initialValues = {};
let dataToBeEdited = {};

const renderError = (formik, fieldName) => {
    return formik.errors[(fieldName)] ? (
        <span className='mb-1 error-text'>
            {formik.errors[(fieldName)]}
        </span>
    ) : null
}
const getClassName = (formik, fieldName) => {
    let returnMsg = "input-text";
    if (formik.errors[(fieldName)]) return returnMsg + " error"
    return returnMsg
}

const dataTypeList = [
    { label: "String", value: "String" },
    { label: "Integer", value: "integer" },
    { label: "Decimal", value: "decimal" },
    { label: "Numeric", value: "numeric" },
    { label: "Check Box", value: "checkBox" },
    { label: "List", value: "List" },
    { label: "Time", value: "time" },
    { label: "Date", value: "date" },
    { label: "DateTime", value: "dateTime" },
];
const handleDataChange = (formik, val) => {
    formik.setFieldValue('dataType', val)
    formik.setFieldValue('fieldValue', '')
    formik.setFieldValue('dataType', val)
    formik.setFieldValue('dataFormat', dataFormat[val])
    if (val === 'String') {
        formik.setFieldValue('fieldDefaultValue', '');
        formik.setFieldValue('fieldValue', '');
    }
    if (val === 'List') {
        formik.setFieldValue('fieldValue', "null");
    }
    else if (val === 'integer' || val === 'decimal') {
        formik.setFieldValue('fieldDefaultValue', 0)
        formik.setFieldValue('fieldValue', 0);
    } else {
        formik.setFieldValue('fieldDefaultValue', '');
    }
}
const dataFormat = { String: '#AANNLL', integer: 'NNNNNN', decimal: '#N.NN', date: 'MM-DD-YYYY', time: 'HH:MM:SS(UTC)', dateTime: 'YYYY-MM-DDThh:mm:ss+0000 (UTC)' }
const formatFinder = { String: 'text', checkBox: 'switch', integer: 'number', decimal: 'number', date: 'date', time: 'time', dateTime: 'date' }
const FindInputType = ({ dataType, className, handleChange, name, placeholder, value, dataObj, disabled }) => {
    const [ipText, setInputText] = useState();
    const [errorMsg, setErrorMessage] = useState();
    const type = formatFinder[dataType];
    let inputEle = '';
    if (dataType === 'dateTime' || dataType === 'date' || dataType === 'time') {
        let constructedDate;
        if (dataType === 'time' && value) {
            constructedDate = new Date();
            constructedDate.setUTCHours(value.split(":")[0])
            constructedDate.setUTCMinutes(value.split(":")[1])
        }
        if (dataType === 'date') {
            let splitList = value.split("-")
            constructedDate = new Date(Date.UTC(splitList[0], parseInt(splitList[1]) - 1, splitList[2]))
        }
        if (dataType === 'dateTime') {
            let replacedString = value.replace("UTC", "GMT");
            constructedDate = new Date(value)
        }
        inputEle = (
            <DateTimePicker
                onChange={(e) => {
                    if (dataType === 'date' && e._d) {
                        dataObj.setFieldValue(name, `${e._d.getUTCFullYear()}-${(e._d.getUTCMonth() + 1).toString().padStart(2, '0')}-${e._d.getUTCDate().toString().padStart(2, '0')} `)
                        if (name === 'fieldDefaultValue') {
                            dataObj.setFieldValue('fieldValue', `${e._d.getUTCFullYear()}-${(e._d.getUTCMonth() + 1).toString().padStart(2, '0')}-${e._d.getUTCDate().toString().padStart(2, '0')} `)
                        }
                    }
                    else if (dataType === 'time' && e._d) {
                        dataObj.setFieldValue(name, `${e._d.getUTCHours().toString().padStart(2, '0')}:${e._d.getUTCMinutes().toString().padStart(2, '0')}`)
                        if (name === 'fieldDefaultValue') {
                            dataObj.setFieldValue('fieldValue', `${e._d.getUTCHours().toString().padStart(2, '0')}:${e._d.getUTCMinutes().toString().padStart(2, '0')}`)
                        }
                    }
                    else if (e._d) {
                        dataObj.setFieldValue(name, e._d.toUTCString().replace("GMT", "UTC"))
                        if (name === 'fieldDefaultValue') {
                            dataObj.setFieldValue('fieldValue', e._d.toUTCString().replace("GMT", "UTC"))
                        }
                    }
                }}
                initialValue={value}
                value={constructedDate}
                dateFormat={dataType === 'time' ? false : "YYYY-MM-DD"}
                timeFormat={dataType === "date" ? false : "hh:mm A"}
                className={`datePicker`}
                key={`${name}_${dataType}`}
                utc={true}
            />
        )
    }
    else if (dataType === 'checkBox') {
        inputEle = (
            <div className="flex gatewaySettingSpl">
                <Form.Group controlId="formBasicCheckbox" className="checkboxGrp">
                    <Form.Check type="checkbox" checked={value === 'Yes'} className="yesCheck" name={name} label="Yes" onChange={(e) => dataObj.setFieldValue(name, 'Yes')} />
                    <Form.Check type="checkbox" checked={value === 'No'} className="noCheck" name={name} label="No" onChange={(e) => dataObj.setFieldValue(name, 'No')} />
                </Form.Group>
            </div>
        )
    } else if (dataType === 'List') {
        inputEle = (
            <>
                <div className="flex">
                    <InputText
                        name='dataText'
                        type="text"
                        labelClassName={"labelClass"}
                        valueClassName={"valueClass"}
                        disabled={disabled}
                        smValue={2}
                        onChange={(e) => { setErrorMessage(''); setInputText(e.target.value) }}
                        rowClassName="rowMargin"
                        className={className}
                        placeholder={"Enter value for data List"}
                        value={ipText}
                    />
                    <Image className="plusIcon" src={PlusIcon} disabled={disabled} onClick={() => {
                        if (ipText && ipText.length > 0) {
                            setInputText('');
                            let tempObj = (dataObj.values.dataList && [...dataObj.values.dataList]) || []
                            dataObj.setFieldValue('dataList', [...tempObj, ipText])
                        } else {
                            setErrorMessage('Please enter value')
                        }
                    }} />
                </div>
                <span className='mb-1 error-text'>
                    {errorMsg}
                </span>
            </>
        )
    } else {
        inputEle = (
            <InputText
                name={name}
                type={type}
                onChange={handleChange}
                labelClassName={"labelClass"}
                valueClassName={"valueClass"}
                smValue={2}
                rowClassName="rowMargin"
                className={className}
                disabled={disabled}
                placeholder={placeholder}
                value={value}
            />
        )
    }
    return (
        inputEle
    )
}

function ViewGatewayProviderSetting(props) {
    const dispatch = useDispatch();
    const history = useHistory();
    const retData = useSelector(state => state.gatewayReducer);
    const { match: { params: { id, providercode } } } = props;
    console.log(id, providercode, "id amnd code")
    let iAmNotAdd;
    if (providercode !== "ADD") {
        iAmNotAdd = providercode;
    }
    useEffect(() => {
        dispatch(retrieveGatewayProviderSetting(id))
    }, []);
    dataToBeEdited = retData?.viewGatewayProviderSetting;
    console.log(dataToBeEdited, "data to be edited")

    let errorDiv = undefined;
    if (retData?.errorResponse) {
        errorDiv = (
            <BDOToast
                openState={true}
                type={"warning"}
                bodyMessage={retData?.errorResponse?.errorDescription}
            />
        )
    }

    if (iAmNotAdd && dataToBeEdited !== undefined) {
        let dataToEdit = dataToBeEdited;
        initialValues = dataToEdit; //This is written to check and update the fields automatically without below lines
        initialValues.fieldCode = dataToEdit.fieldCode || '';
        initialValues.fieldName = dataToEdit.fieldName || '';
        initialValues.fieldValue = dataToEdit.fieldValue || '';
        initialValues.fieldDescription = dataToEdit.fieldDescription || '';
        initialValues.dataType = dataToEdit.dataType || '';
        initialValues.fieldDefaultValue = dataToEdit.fieldDefaultValue || '';
        initialValues.maximumValue = dataToEdit.maximumValue || '';
        initialValues.minimumValue = dataToEdit.minimumValue || '';
        initialValues.status = dataToEdit?.status;
        initialValues.required = dataToEdit.required;
        initialValues.affectedModules = dataToEdit.affectedModules || '';
        initialValues.reason = dataToEdit.reason || '';
    }
    if (!initialValues.required) {
        initialValues.required = true;
    }
    if (!initialValues.status) {
        initialValues.status = "inactive";
    }
    const formik = useFormik({
        enableReinitialize: true,
        initialValues,
        validationSchema: Yup.object({
            fieldCode: Yup.string()
                .max(10, 'Must be 10 characters or less')
                .required('Required'),
            fieldName: Yup.string()
                .matches(/^[A-Za-z0-9._ -]*$/, 'Please enter valid name')
                .max(50, 'Must be 50 characters or less')
                .required('Required'),
            fieldValue: Yup.string()
                .required('Required'),
            fieldDescription: Yup.string()
                .max(200, 'Must be 200 characters or less')
                .required('Required'),
            dataType: Yup.string().required('Required'),
            // fieldDefaultValue: Yup.string()
            //   .max(50, 'Must be 50 characters or less')
            //   .required('Required'),
            maximumValue: Yup.number()
                .typeError("That doesn't look like a number")
                .positive("Number can't be negative")
                .max(50000, 'Must be 50000 or less')
                .integer("Number can't include a decimal point"),
            minimumValue: Yup.number()
                .typeError("That doesn't look like a number")
                .positive("Number can't be negative")
                .max(50000, 'Must be 50000 or less')
                .integer("Number can't include a decimal point"),
            affectedModules: Yup.string()
                .max(200, 'Must be 200 characters or less')
                .required('Required'),
            reason: Yup.string().required('Required'),
            required: Yup.string().required('Required'),
            status: Yup.string().required('Required')
        }),
        onSubmit: values => {
            console.log(values);
            history.push({ pathname: `/gatewaymanagment/gatewayProviders/${id}`, state: { values } })
        },
        validate: values => {
            let errors = {};
            if ((values.dataType === 'integer' || values.dataType === 'decimal') && !values.minimumValue) {
                errors.minimumValue = 'Minimum value is required';
            }
            if ((values.dataType === 'integer' || values.dataType === 'decimal') && !values.maximumValue) {
                errors.maximumValue = 'Maximum value is required';
            }
            if (values.minimumValue && values.maximumValue) {
                if (values.minimumValue > values.maximumValue) {
                    errors.minimumValue = 'Minimum value should not be greater than maximum value';
                }
                if (values.fieldValue < values.minimumValue || values.fieldValue > values.maximumValue) {
                    errors.fieldValue = 'Provider Setting value should be between minimum and maximum values';
                }
            }
            return errors;
        }
    });
    const handleSwitchChange = (name, value) => {
        if (name === "status") {
            formik.setFieldValue(name, value ? 'active' : 'inactive');
        } else {
            formik.setFieldValue(name, value);
        }
    }

    function goBack() {
        formik.resetForm();
        initialValues = {};
        history.push(`/gatewaymanagment/gatewayProviders/${id}`);
    }
    return (
        <div className="addCcm viewLayout-gm mt-2">
            <div className="redirect">
                <Image onClick={goBack} src={backIcon} className="icon" />
                <b>{(iAmNotAdd) ? `${formik.values.fieldCode}` : `Add Gateway Settings`}</b>
            </div>

            <Form onSubmit={formik.handleSubmit}>
        {(!errorDiv) ?
          (
            <Card className="cardbodystyle border-0">
              <Card.Body >
                <Row className="mt-2 mr-2 ml-2">
                  <Col xs='2' sm='2' >
                    <div className=''>
                      <label htmlFor='fieldCode' className=''>Provider Setting Code </label>
                    </div>
                  </Col>
                  <Col xs='5' sm='5'>
                    <InputText
                      className={getClassName(formik, 'fieldCode')}
                      value={formik.values.fieldCode}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      name='fieldCode'
                      disabled={iAmNotAdd ?true : false}
                      placeholder='Enter Provider Setting code'
                    />
                    {renderError(formik, 'fieldCode')}
                  </Col>
                </Row>
                {console.log('vale', formik.values,formik.errors)}
                <Row className="mt-2 mr-2 ml-2">
                  <Col xs='2' sm='2' >
                    <div className=''>
                      <label htmlFor='fieldName' className=''>Provider Setting Name </label>
                    </div>
                  </Col>
                  <Col xs='5' sm='5'>
                    <InputText
                      className={getClassName(formik, 'fieldName')}
                      value={formik.values.fieldName}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      name='fieldName'
                      placeholder='Enter Provider Setting name'
                    />
                    {renderError(formik, 'fieldName')}
                  </Col>
                </Row>
                <Row className="mt-2 mr-2 ml-2">
                  <Col xs='2' sm='2' >
                    <div className=''>
                      <label htmlFor='fieldDescription' className=''>Provider Setting Description </label>
                    </div>
                  </Col>
                  <Col xs='5' sm='5'>
                    <InputText
                      as="textarea"
                      rows={3}
                      className={getClassName(formik, 'fieldDescription')}
                      value={formik.values.fieldDescription}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      name='fieldDescription'
                      placeholder='Enter Provider Setting description'
                    />
                    {renderError(formik, 'fieldDescription')}
                  </Col>
                </Row>
                <Row className="mt-2 mr-2 ml-2">
                  <Col xs='2' sm='2' >
                    <div className=''>
                      <label htmlFor='dataType' className=''>Data Type </label>
                    </div>
                  </Col>
                  <Col xs='5' sm='5'>
                    <BDOSelect
                      name="dataType"
                      options={dataTypeList}
                      value={formik.values.dataType}
                      placeholder={"Select datatype"}
                      onChange={(e) => {
                        handleDataChange(formik, e.value)
                      }}
                    />
                    {renderError(formik, 'dataType')}
                  </Col>
                </Row>
                {
                  (formik.values.dataType !== 'List' && formik.values.dataType !== 'checkBox')
                    ? (<Row className="mt-2 mr-2 ml-2">
                      <Col xs='2' sm='2' >
                        <div className=''>
                          <label htmlFor='dataFormat' className=''>Provider Setting Data Format </label>
                        </div>
                      </Col>
                      <Col xs='5' sm='5'>
                        <InputText
                          className={getClassName(formik, 'dataFormat')}
                          value={formik.values.dataFormat}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                          name='dataFormat'
                          placeholder='Enter Provider Setting Data Format'
                        />
                      </Col>
                    </Row>
                    ) : ''
                }
                {
                  (formik.values.dataType !== 'List' && formik.values.dataType !== 'checkBox')
                    ? (
                      <Row className="mt-2 mr-2 ml-2">
                        <Col xs='2' sm='2' >
                          <div className=''>
                            <label htmlFor='fieldDefaultValue' className=''>Provider Setting default value </label>
                          </div>
                        </Col>
                        <Col xs='5' sm='5'>
                          <>
                            <FindInputType
                              dataType={formik.values.dataType}
                              handleChange={(e) => {
                                formik.handleChange(e)
                                formik.setFieldValue('fieldValue', e.target.value)
                              }}
                              onBlur={formik.handleBlur}
                              name={"fieldDefaultValue"}
                              placeholder={'Enter Default Value'}
                              dataObj={{ setFieldValue: formik.setFieldValue, values: formik.values }}
                              value={formik.values.fieldDefaultValue}
                              className={getClassName(formik, 'fieldDefaultValue')}
                            />
                            {renderError(formik, 'fieldDefaultValue')}
                          </>
                        </Col>
                      </Row>
                    ) : null
                }
                {
                  (formik.values.dataType === 'integer' || formik.values.dataType === 'decimal')
                    ? (
                      <>
                        <Row className="mt-2 mr-2 ml-2">
                          <Col xs='2' sm='2' >
                            <div className=''>
                              <label htmlFor='minimumValue' className=''>Minimum Value </label>
                            </div>
                          </Col>
                          <Col xs='5' sm='5'>
                            <InputText
                              type="number"
                              className={getClassName(formik, 'minimumValue')}
                              value={formik.values.minimumValue}
                              onChange={formik.handleChange}
                              onBlur={formik.handleBlur}
                              name='minimumValue'
                              placeholder='Enter minimum value'
                            />
                            {renderError(formik, 'minimumValue')}
                          </Col>
                        </Row>
                        <Row className="mt-2 mr-2 ml-2">
                          <Col xs='2' sm='2' >
                            <div className=''>
                              <label htmlFor='maximumValue' className=''>Maximum Value</label>
                            </div>
                          </Col>
                          <Col xs='5' sm='5'>
                            <InputText
                              type="number"
                              className={getClassName(formik, 'maximumValue')}
                              value={formik.values.maximumValue}
                              onChange={formik.handleChange}
                              onBlur={formik.handleBlur}
                              name='maximumValue'
                              placeholder='Enter maximum value'
                            />
                            {renderError(formik, 'maximumValue')}
                          </Col>
                        </Row>
                      </>
                    ) : ''
                }
                <Row className="mt-2 mr-2 ml-2">
                  <Col xs='2' sm='2' >
                    <div className=''>
                      <label htmlFor={formik.values.dataType !== "List" ? "Provider Setting Value" : "DataList Value"} className=''>{formik.values.dataType !== "List" ? "Provider Setting Value" : "DataList Value"}  </label>
                    </div>
                  </Col>
                  <Col xs='5' sm='5'>
                    <>
                      <FindInputType
                        dataType={formik.values.dataType}
                        handleChange={formik.handleChange}
                        name={formik.values.dataType !== "List" ? "fieldValue" : "dataList"}
                        onBlur={formik.handleBlur}
                        placeholder={'Enter Value'}
                        value={((formik.values.fieldValue === undefined || formik.values.fieldValue ==='') ? formik.values?.fieldDefaultValue : formik.values.fieldValue)}
                        dataObj={{ setFieldValue: formik.setFieldValue, values: formik.values }}
                        className={getClassName(formik, formik.values.dataType !== "List" ? "fieldValue" : "dataList")}
                      />
                      {renderError(formik, formik.values.dataType !== "List" ? "fieldValue" : "dataList")}
                    </>
                  </Col>
                </Row>
                {
                  (formik.values.dataType === 'List') ? (
                    <Row className="mt-2 mr-2 ml-2">
                      <Col xs='2' sm='2' >
                        <div className=''>
                          <label htmlFor='fieldValue' className=''>Datalist</label>
                        </div>
                      </Col>
                      <Col xs='5' sm='5'>
                        <select
                          name="fieldValue"
                          className={`form-control  ${getClassName(formik, 'fieldValue')}`}
                          value={formik.values.fieldValue}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                        >
                          <>
                            {(formik.values.dataList && formik.values.dataList.map((elem) => (
                              <option value={elem}>{elem}</option>
                            )))}
                          </>
                        </select>
                        {renderError(formik, 'fieldValue')}
                      </Col>
                    </Row>
                  ) : ''
                }
                <Row className="mt-2 mr-2 ml-2">
                  <Col xs='2' sm='2' >
                    <div className=''>
                      <label htmlFor='reason' className='' >Required </label>
                    </div>
                  </Col>
                  <Col xs='5' sm='5'>
                    <Switch
                      type="switch"
                      id={`custom-switch-${formik?.values?.fieldCode}-required`}
                      onChange={(e) => handleSwitchChange("required", e.target.checked)}
                      checked={formik?.values.required}
                    />
                    {renderError(formik, 'required')}
                  </Col>
                </Row>
                <Row className="mt-2 mr-2 ml-2">
                  <Col xs='2' sm='2' >
                    <div className=''>
                      <label htmlFor='affectedModules' className=''>Affected Modules </label>
                    </div>
                  </Col>
                  <Col xs='5' sm='5'>
                    <InputText
                      className={getClassName(formik, 'affectedModules')}
                      value={formik.values.affectedModules}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      name='affectedModules'
                      placeholder='Enter affected modules'
                    />
                    {renderError(formik, 'affectedModules')}
                  </Col>
                </Row>
                <Row className="mt-2 mr-2 ml-2">
                  <Col xs='2' sm='2' >
                    <div className=''>
                      <label htmlFor='reason' className=''>Status</label>
                    </div>
                  </Col>
                  <Col xs='5' sm='5'>
                    <Switch
                      type="switch"
                      id={`custom-switch-${formik?.values?.fieldCode}`}
                      onChange={(e) => handleSwitchChange("status", e.target.checked)}
                      checked={formik.values.status === "active"}
                    />
                    {renderError(formik, 'status')}
                  </Col>
                </Row>
                <Row className="mt-2 mr-2 ml-2">
                  <Col xs='2' sm='2' >
                    <div className=''>
                      <label htmlFor='reason' className=''>Reason</label>
                    </div>
                  </Col>
                  <Col xs='5' sm='5'>
                    <InputText
                      className={getClassName(formik, 'reason')}
                      value={formik.values.reason}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      name='reason'
                      placeholder='Enter reason '
                    />
                    {renderError(formik, 'reason')}
                  </Col>
                </Row>
              </Card.Body>
            </Card>
          ) : (
            errorDiv
          )}
                <div className='mt-4 mb-4 float-right'>
                    <BDOButton onClick={goBack} title="Cancel" style1="style2 mr-3" />
                    <BDOButton type="submit" title={iAmNotAdd
                        ? 'Save'
                        : 'Add'} style1="style1" />
                </div>
            </Form>
        </div>
    );
}
export default ViewGatewayProviderSetting;
