import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from "react-redux";
import {
    Card, Row, Col, Button,
    Image, Spinner
} from 'react-bootstrap';
import {useHistory, Link } from 'react-router-dom';
import SearchBar from '../Global/SearchBar/SearchBar';
import DataTable from '../Global/DataTable/DataTable';
import EditIcon from '../../assets/icons/icon-edit-filled.svg';
import Switch from '../Global/Switch/Switch';
import { retrieveAllGatewayProvider }  from '../../actions/gatewaymanagement';
import './styles/viewAllGatewayType.scss';

const editIcon =(rowData , toggle)=> (<Image onClick={() => toggle('EDIT' , rowData)} src={EditIcon} className="icon"/>);
function ViewAllGatewayProvider(props) {
    const dispatch = useDispatch();
    const retData = useSelector( state => state.gatewayReducer);
    const { viewAllGatewayProvider=[] }  = retData;
    let  { data }= viewAllGatewayProvider;
    const history = useHistory();
    useEffect(() => {
        dispatch(retrieveAllGatewayProvider());           
    }, []);
    let [ localData=data, setData] = useState();

    let toggle = (toggleaction , datatochild) => {
        if(toggleaction==="ADD"){
        history.push({pathname: `/gatewaymanagment/gatewayProviders/ADD`, state: {toggleaction,datatochild }})
        }else if(toggleaction!=="ADD"){
            history.push({pathname: `/gatewaymanagment/gatewayProviders/${datatochild.code}`, state: {toggleaction,datatochild }})
        }
      };
    const categoryList = [
        {'key': 'Provider Code', 'value': 'code'},
        {'key': 'Provider Name', 'value': 'name'},
        {'key': 'Provider Switch', 'value': 'switch'},
        {'key': 'Status', 'value': 'status'},
    ];
    const columns = [
        {
            Header: 'Provider Code',
            accessor: 'code',
            selector: 'code',
            sortType: 'basic',
        },
        {
            Header: 'Provider Name',
            accessor: 'name',
            
        },
        {
            Header: 'Provider Switch',
            accessor: 'switch'
        },
        {
            Header: 'Action',
            accessor: 'action',
            disableSortBy: true
        }
    ];
    const  handleClick = ( category, ipText ) => { 
        const condtnFn = (ele) => ele[(category)] !== undefined && ele[(category)].toLowerCase().includes(ipText)
        const categoryFilterdData = [ ...data ].filter(condtnFn);
        setData(categoryFilterdData);
    }
    const linkDiv = (rowData) => <Link to={`/gatewaymanagment/gatewayProviders/${rowData.code}`}>{rowData.name}</Link>;
    const statusDiv = (rowData) => (
        <div className="actionDiv">
            <Switch
                type="switch"
                id={`custom-switch-${rowData.code}`}
                defaultChecked={data.status === 'active'}
            />
            {editIcon(rowData,toggle)}
        </div>
    )
    localData = localData && localData.map((ele) => {
        return {
            ...ele, name: linkDiv(ele), action: statusDiv(ele)
        }
    });
    return(
        <div className="gateWayTypeManagement">
            <div className="headerBlock">
                <div>
                    <b>Manage Gateway</b>
                </div>
                <div className="buttonBlock">
                    <Button variant="primary"  onClick={(e) => toggle('ADD')} >Add pROVIDER </Button>
                </div>
            </div>
            <Card>
                <Card.Body>
                    <div className="searchCard">
                        <Row className="mb10">
                            <Col sm={8}>
                                <b className="ml10">Search Gateway Provider</b>
                            </Col>
                        </Row>
                        <div className="formBlock">
                            <SearchBar categoryList={categoryList} textPlaceHolder="Enter Settings" handleClick={handleClick}/>
                        </div>  
                    </div>
                </Card.Body>
            </Card>
            <div className="tableBlock">
                <Card>
                    <Card.Body>
                        <h6 className="header6">Gateway Provider</h6>
                        <div className="dataBlock">
                            {
                                localData !== undefined
                                ?  (
                                <DataTable 
                                    columns={columns}
                                    data={localData}
                                    showPagination={true}
                                />):(
                                    <div className="alignCenter">
                                        <Spinner animation="border" />
                                    </div>
                                )
                            }
                        </div>
                    </Card.Body>
                </Card>
            </div>

        </div>
    )
}
export default ViewAllGatewayProvider;
