import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from "react-redux";
import {
    Card, Button, Row, Col,
    Image, Spinner
} from 'react-bootstrap';
import { Link , useHistory} from 'react-router-dom';
import SearchBar from '../Global/SearchBar/SearchBar';
import DataTable from '../Global/DataTable/DataTable';
import EditIcon from '../../assets/icons/icon-edit-outline.svg';
import Switch from '../Global/Switch/Switch';
import { retrieveAllGatewayType }  from '../../actions/gatewaymanagement';
import BDOButton from '../Global/Button/BDOButton';
import './styles/viewAllGatewayType.scss';
    

const editIcon =(rowData , toggle)=> (<Image onClick={() => toggle('EDIT' , rowData)} src={EditIcon} className="icon"/>);

const actionDiv = ( ele, handleStatusChange ,toggle ) => (
    (ele.status ==="active" || ele.status ==="inactive")
    ? (<div className="actionDiv" key={`action_${ele.code}`}>
            <Switch
                    type="switch"
                    id={`custom-switch-${ele.code}`}
                    defaultChecked={ele.status === 'active'}
                    onChange={(e) => handleStatusChange(e.target.checked, ele.code)}
                />
            <div className="editDiv">{editIcon(ele , toggle)}</div>
        </div>
    ): ''
)


const alphaNumericSorting = (frstValue, scndValue, colId, desc=false) => {
    if( frstValue && scndValue ){
        if( !desc ) return frstValue.localeCompare(scndValue)
        return (-1 *(scndValue.localeCompare(frstValue)))
    }
}

const statusDiv = (rowData) => {
    const { status } = rowData;
    let className = 'forApproval';
    let text = 'For Approval';
    if( status === "active" || status === "inactive") {
        className = "status"+status;
        text= status[0].toUpperCase() + status.substring(1, status.length)
    }
    return ( <div className={className}>{text}</div>)
};

const sortByElement = ( rowA, rowB, colId, desc) => {
    const findFn = ( entry ) => entry.column && (entry.column.id ===  colId)
    const foundAData = rowA.cells.find(findFn);
    const foundBData = rowB.cells.find(findFn);
    const aValue =  typeof rowA.cells[0] !== "function" && foundAData && foundAData.value.props.children;
    const bValue =  typeof rowB.cells[0] !== "function" && foundBData && foundBData.value.props.children;
    return alphaNumericSorting( aValue, bValue, colId, desc)
}

function ViewAllGatewayType(props) { 
    const history = useHistory();
    const { isupdate, iscreate } = props;
    const dispatch = useDispatch();
    const retData = useSelector( state => state.gatewayReducer);
    let { viewAllGatewayType=[] }  = retData;
    const { data , totalPages=1} = viewAllGatewayType;
    useEffect(() => {
        dispatch(retrieveAllGatewayType(`page=${0}&size=${10}`));           
    }, []);
    let [ localData=data, setData] = useState();
    let [ activeRow, setActiveRow] = useState([]);
    const categoryList = [
        {'key': 'Gateway Code', 'value': 'code'},
        {'key': 'Gateway Name', 'value': 'name'},
        {'key': 'Gateway Description', 'value': 'description'}
    ];

    const handleHeaderCheck = ( value ) => {
        (value === true)
            ? setActiveRow( [...localData.map((entry) => entry.code)])
            : setActiveRow([]);
    }
    let columns = [
        {
            Header: (
                <Switch
                    onClick={(e) => handleHeaderCheck(e.target.checked)} 
                />
            ),
            accessor: 'checkBox',
            disableSortBy: true,
        },
        {
            Header: 'Gateway Code',
            accessor: 'code',
            selector: 'code',
            sortType: 'basic',
        },
        {
            Header: 'Gateway Name',
            accessor: 'name',
            sortType: ( rowA, rowB, colId, desc ) => {
                return sortByElement(rowA, rowB, colId, desc)
            }
        },
        {
            Header: 'Description',
            accessor: 'description',
        },
        {
            Header: 'Status',
            accessor: 'status',
            sortType:( rowA, rowB, colId, desc ) => {
                return sortByElement(rowA, rowB, colId, desc)
            }
        }
    ];
    if( isupdate ) {
        columns = [ 
            ...columns,  {
            Header: 'Actions',
            accessor: 'actions',
            disableSortBy: true,
            }
        ];
    }

    const handleServerSidePagination = ( pageNo, pageSize ) => {
        dispatch(retrieveAllGatewayType(`page=${pageNo}&size=${pageSize}`));
    }
    let toggle = (toggleaction , datatochild) => {
        history.push({pathname: '/gatewaymanagment/EnrollGateway', state: {toggleaction , datatochild}})
      };
    const  handleClick = ( category, ipText ) => {
        const condtnFn = (ele) => {
            if(ele[(category)] && isNaN(ele[(category)])) {
              if( ele[(category)].toLowerCase().includes(ipText.toLowerCase())) return true
            }
            else if ( ele[(category)] && ele[(category)] === parseInt(ipText)) return true;
            return false;
        }
        const categoryFilterdData = [ ...data ].filter(condtnFn);
        setData(categoryFilterdData );
    }
    const linkDiv = (rowData) => <Link to={`/gatewaymanagment/${rowData.code}`}>{rowData.name}</Link>;
    const handleStatusChange = ( value, code ) => {
        const finder = data.find(( ele ) => ele.code === code);
        finder["status"] = value?"active": "inactive";
        setData([...data]);
    }
    
    const handleCheckList = ( value, code ) => {
        const idx = activeRow.indexOf( code );
        if( value) setActiveRow( [...activeRow, code ] );
        else {
            activeRow.splice( idx, 1);
            setActiveRow([...activeRow])
        }
    }
    const localObj = localData && localData.map((ele) => {
            return {
                checkBox: (
                    <Switch
                        onChange={(e) => handleCheckList(e.target.checked, ele.code)} 
                        checked={activeRow.indexOf(ele.code) !== -1}
                    />),
                ...ele,
                name: linkDiv(ele), 
                status: statusDiv(ele),
                actions: actionDiv(ele, handleStatusChange , toggle),
                className: activeRow.find((itr) => itr === ele.code)? 'activeRow' :'',
            }
        });
    return(
        <div className="gateWayTypeManagement">
            <div className="headerBlock">
                <div>
                    <b>Manage Gateway</b>
                </div>
                <div className="buttonBlock">
                { iscreate && ( <BDOButton title="Add Gateway" onClick={(e) => toggle('ADD')} style1="style1" />)}
                </div>
            </div>
            <Card className="searchBlock">
                <Card.Body>
                    <div className="searchCard">
                        <Row className="mb10">
                            <Col sm={8}>
                                <b className="ml10">Search Gateway</b>
                            </Col>
                        </Row>
                        <div className="formBlock">
                            <SearchBar categoryList={categoryList} textPlaceHolder="Input Keyword" handleClick={handleClick}/>
                        </div>  
                    </div>
                </Card.Body>
            </Card>
            <div className="tableBlock">
                <Card>
                    <Card.Body>
                        <div  className="mb10">
                            <b className="header6">Gateways</b>
                        </div>
                        <div className="btnBlock">
                            {
                                (activeRow.length > 0) 
                                ? (
                                    <>
                                        <Button variant="primary">Deactivate</Button>
                                        <span className="highlighter">{activeRow.length} items selected</span>
                                    </>
                                ) : ''
                            }
                        </div>
                        <div className="dataBlock">
                            {
                                localObj !== undefined
                                ?  (
                                <DataTable 
                                    columns={columns}
                                    data={localObj}
                                    showPagination={true}
                                    // handleServerSidePagination={handleServerSidePagination}
                                    pageProperty={{ totalPages}}
                                />):(
                                    <div className="alignCenter">
                                        <Spinner animation="border" />
                                    </div>
                                )
                            }
                        </div>
                    </Card.Body>
                </Card>
            </div>

        </div>
    )
}
export default ViewAllGatewayType;
