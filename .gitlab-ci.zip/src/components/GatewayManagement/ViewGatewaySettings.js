import React, { useState, useRef } from 'react';
import  {  useSelector } from 'react-redux';
import DetailsLabel from './DetailsLabel';
import { 
    Card,Image, Button, Form,
} from 'react-bootstrap';
import { Link, useHistory } from 'react-router-dom';
import './styles/viewGatewaySettings.scss';
import Switch from '../Global/Switch/Switch';
import backIcon from '../../assets/icons/backIcon.png';
import ConfirmationModal from '../Global/ConfirmationModal/ConfirmationModal';
import InputText from '../../components/Global/Input/InputText';
import { Formik }  from 'formik';
import DateTimePicker from '../Global/DateTimePicker/DateTimePicker';
import PlusIcon from '../../assets/icons/plus_icon.svg'
import * as Yup from 'yup';

const dataTypeList = [
    { key: "String", value: "string" },
    { key: "Integer", value: "integer" },
    { key: "Decimal", value: "decimal" },
    { key: "Check Box", value: "checkBox" },
    { key: "List", value: "list" },
    { key: "Time", value: "time" },
    { key: "Date", value: "date" },
    { key: "DateTime", value: "dateTime" },
];

const renderError = ( formik, paramname) => (
        formik.errors[(paramname)] ? (
            <span className='mb-1 error-text'>
                {formik.errors[(paramname)]} 
            </span>
        ) : null
    )

  
const getClassName = (formik, paramname) => {
    let returnMsg = "input-text";
    if( formik.errors[(paramname)] ) return returnMsg+" error"
    return returnMsg
}

const handleDataChange = (setFieldValue, val, setErrors, setNumber) => {
    setFieldValue('dataType', val)
    setFieldValue('value', '')
    if( val === '') setErrors('dataType', false)
    else setErrors('dataType', true)
    setFieldValue('dataType', val)
    setFieldValue('dataFormat', dataFormat[val])
    if( val === 'string' ) {
        setFieldValue('defaultValue', '');
        setFieldValue('value', '');
        setNumber(false)
    }
    else if( val === 'integer' || val === 'decimal'){
        setFieldValue('defaultValue', 0)
        setFieldValue('value', 0);
        setNumber(true)
    } else {
        setFieldValue('defaultValue', '');
        setNumber(false)
    }
}

const categoryOption = (
    (dataTypeList.length > 0)
    ?( 
        <>
            <option key="Select category" value="">Select data type</option>
            {dataTypeList.map((ele) => <option key={ele.value} value={ele.value}>{ele.key}</option>)}
        </>
    )
    :''
)

const dataFormat = { string: '#AANNLL', integer: 'NNNNNN', decimal: '#N.NN', date: 'MM-DD-YYYY', time: 'HH:MM:SS(UTC)', dateTime: 'YYYY-MM-DDThh:mm:ss+0000 (UTC)'}
const formatFinder = { string: 'text', checkBox: 'switch', integer: 'number', decimal: 'number', date: 'date', time: 'time', dateTime: 'date'}

const FindInputType = ({ dataType, className, handleChange, name, placeholder, value, dataObj }) => {
    const [ ipText, setInputText ] = useState();
    const [ errorMsg, setErrorMessage ] = useState();
    const type = formatFinder[dataType];
    let inputEle = '';
    if( dataType === 'dateTime' || dataType === 'date' || dataType === 'time') {
        inputEle = (
            <DateTimePicker 
                onClose={(e) => {
                    if( dataType === 'date' && e._d) dataObj.setFieldValue(name, `${e._d.getUTCFullYear()}-${(e._d.getUTCMonth() +1).toString().padStart(2,'0')}-${e._d.getUTCDate().toString().padStart(2,'0')} `)
                    else if( dataType === 'time' && e._d) dataObj.setFieldValue(name, `${e._d.getUTCHours().toString().padStart(2,'0')}:${e._d.getUTCMinutes().toString().padStart(2,'0')}`)
                    else if(e._d) dataObj.setFieldValue(name, e._d.toUTCString().replace("GMT","UTC"))
                }}
                initialValue={value} 
                dateFormat={dataType === 'time'? false: "YYYY-MM-DD"}
                timeFormat={dataType === "date"? false: "hh:mm A"}
                className={`datePicker`}
                key={`${name}_${dataType}`}
                utc={true}
            />
        )
    }
    else if( dataType === 'checkBox') {
        inputEle = (
            <div className="flex gatewaySettingSpl">
                <Form.Group controlId="formBasicCheckbox" className="checkboxGrp">
                    <Form.Check type="checkbox" checked={value} className="yesCheck" name={name} label="Yes" onChange={(e) => dataObj.setFieldValue(name,!value)}/>
                    <Form.Check type="checkbox" checked={!value} className="noCheck" name={name} label="No" onChange={(e) => dataObj.setFieldValue(name,!value)}/> 
                </Form.Group>
            </div>
        )
    } else if(dataType === 'list') {
        inputEle = (
            <>
                <div className="flex">
                    <InputText 
                        name='dataText'
                        type="text"
                        labelClassName={"labelClass"}
                        valueClassName={"valueClass"}
                        smValue={2}
                        onChange={(e) => { setErrorMessage('');setInputText(e.target.value)}}
                        rowClassName="rowMargin"
                        className={className} 
                        placeholder={"Enter value for data list"}
                        value={ipText}
                    />
                    <Image className="plusIcon" src={PlusIcon} onClick={() => {
                        if( ipText && ipText.length > 0 ) {
                            setInputText('');
                            let tempObj = ( dataObj.values.dataList && [...dataObj.values.dataList]) || []
                            dataObj.setFieldValue('dataList', [...tempObj, ipText])
                        } else {
                            setErrorMessage('Please enter value')
                        }
                    }} />
                </div>   
                <span className='mb-1 error-text'>
                    {errorMsg} 
                </span>
            </>
        )
    } else {
        inputEle = (
            <InputText 
                name={name}
                type={type}
                labelClassName={"labelClass"}
                valueClassName={"valueClass"}
                smValue={2}
                onChange={handleChange}
                rowClassName="rowMargin"
                className={className}
                placeholder={placeholder}
                value={value}
            />
        )
    }
    return (
        inputEle
    )
}


function ViewGatewaySettings(props) {
    const history = useHistory();
    const pushToApi =(values) => console.log(values, 'in api');
    const { viewGateway={} } = useSelector( stateRed => stateRed.gatewayReducer);
    const { match: {params: { id }} , location: { state = {}}} = props;
    const {  storage, idx } = state;
    const { data = {}} = viewGateway;
    
    const { gatewaySettings = [], gatewayTypeDetails = {}} = data;
    const handleSubmit = ( storageType,values ) => {
        if( storageType === "local") {
            const tempObj = viewGateway;
            if( id === "add") {
                tempObj.data.gatewaySettings.push({ ...values });
            } else {
                tempObj.data.gatewaySettings[idx] = values;
            }
        } else {
            pushToApi(values)
        }
    }
    const recData = gatewaySettings[idx] || {}
    const gatewayCode = gatewayTypeDetails.code;
    const [ settingsData = recData, ] = useState()
    const [ isNumber, setNumber ] = useState(false)
    const [ openConfirmModal, setConfirmModal ] = useState(false);
    const [ resultValue, setResultValue ] = useState({});
    const { 
        code, name,
    } = settingsData;
    const formIkRef = useRef();
    const goBack = () => {
        if( id === 'add' && gatewayCode === undefined) history.goBack();
        if( storage === "local") history.push({ pathname: `/gatewaymanagment/${gatewayCode?gatewayCode:''}`, dataFrom: "localState"});
        else history.push(`/gatewaymanagment/${gatewayCode?gatewayCode:''}`);
    }
    let validationSchema = {
        code: Yup.string()
            .matches(/^[a-z0-9\s]+$/i, { message: 'Enter only alpha numeric characters'})
            .max(50, 'Must be 50 characters or less')
            .required('Required field'),
        name: Yup.string()
            .matches(/^[a-z0-9\s]+$/i, { message: 'Enter only alpha numeric characters'})
            .max(50, 'Must be 50 characters or less')
            .required('Required field'),
        dataType: Yup.string().required('Required field'),
        status: Yup.string().required('Required field'),
        affectedModule: Yup.string()
            .max(200, 'Must be 200 characters or less')
            .required('Required field'),
        description: Yup.string()
            .max(200, 'Must be 200 characters or less')
            .required('Required field'),
        reason: Yup.string()
            .max(200, 'Must be 200 characters or less')
            .required('Required field'),
        value: Yup.mixed()
            .required('Required field'),
    };
    if( isNumber ) {
        validationSchema = {
            ...validationSchema,
            maximumValue: Yup.number().required('Required field'),
            minimumValue: Yup.number().required('Required field')
        }
    } else {
        validationSchema = { ...validationSchema }
    }
    let addInitialValue = {}; 
    if( id !== 'add') {
        addInitialValue= { reason: settingsData?.reason?settingsData.reason:""}
    }
    const getValueText = ( value ) => value ?"Enabled":"Disabled"
    const getRequiredText = ( value ) => value ?"Yes":"No"
    return(
        <div className="gatewaySettingBody">
            <div className="redirect">
                <Link to={`/gatewaymanagment/:${id}`}>
                    <Image src={backIcon}  className="icon"/>
                </Link>
                <b>{ (id==='add')? `Add Gateway Settings`: `${code} - ${ name}`}</b>
            </div>
            {
                openConfirmModal && (
                    <ConfirmationModal 
                        openState={openConfirmModal}
                        confirmHandler={goBack}
                        cancelHandler={() => setConfirmModal(false)}
                        headerText={"Gateway Settings"}
                        bodyContent={"Do you want to add gateway settings ?"}
                        contentObj={resultValue}
                        modalSize={"lg"}
                        descriptionWidth={75}
                    />
                ) 
            }
            <Card>
                <div className="cardHeader">
                    Gateway Settings Detailcccccccccccccccccc
                </div>
                <Card.Body>
                    <Card.Text>
                        <Formik
                            initialValues={{status:false, required:false, ...settingsData,...addInitialValue}}
                            enableReinitialize
                            validationSchema={Yup.object().shape(validationSchema)}
                            onSubmit={(values) => {
                                setConfirmModal(true);
                                setResultValue(values);
                                handleSubmit(storage,values)
                            }}
                            innerRef={formIkRef}
                        >
                            {({ 
                                errors, touched, values, handleChange,
                                setFieldValue, handleBlur, setErrors
                            }) => (
                                <Form>
                                    <DetailsLabel 
                                        labelName={"Code"} 
                                        valueName={
                                            <>
                                                <InputText 
                                                    value={values.code} 
                                                    name="code"
                                                    onBlur={handleBlur}
                                                    className={`feildLabel ${getClassName({ errors, touched }, 'code')}`}
                                                    disabled={values.code=== id}
                                                    onChange={ handleChange}
                                                    placeholder={"Enter Setting Code"}
                                                />
                                                {renderError({errors, touched }, 'code')}
                                            </>}
                                        labelClassName={"labelClass"}
                                        valueClassName={"valueClass"}
                                        smValue={2}
                                        rowClassName="rowMargin"
                                    />
                                    <DetailsLabel 
                                        labelName={"Name"} 
                                        valueName={
                                            <>
                                                <InputText
                                                    placeholder={"Enter Setting name"} 
                                                    onChange={ handleChange} 
                                                    name="name"
                                                    onBlur={handleBlur}
                                                    value={values.name} 
                                                    className={`feildLabel ${getClassName({ errors, touched }, 'name')}`}
                                                />
                                                {renderError({errors, touched }, 'name')}
                                            </>
                                        }
                                        labelClassName={"labelClass"}
                                        valueClassName={"valueClass"}
                                        smValue={2}
                                        rowClassName="rowMargin"
                                    />
                                    <DetailsLabel 
                                        labelName={"Description"} 
                                        valueName={
                                            <>
                                                <InputText 
                                                    placeholder={"Enter Setting Description"} 
                                                    onChange={ handleChange} 
                                                    name="description"
                                                    onBlur={handleBlur}
                                                    as="textarea" 
                                                    value={values.description} 
                                                    rows={3} 
                                                    className={`feildLabel ${getClassName({ errors, touched }, 'description')}`}  
                                                />
                                                {renderError({errors, touched }, 'description')}
                                            </>
                                        }
                                        labelClassName={"labelClass"}
                                        valueClassName={"valueClass"}
                                        smValue={2}
                                        rowClassName="rowMargin"
                                    />
                                    <DetailsLabel 
                                        labelName={"Data Type"} 
                                        valueName={
                                            <>
                                                <Form.Control 
                                                    as="select" 
                                                    name="dataType" 
                                                    aria-label="Select Category" 
                                                    value={values.dataType}
                                                    onBlur={handleBlur} 
                                                    onChange={(e) => {
                                                        handleDataChange( setFieldValue, e.target.value, setErrors, setNumber )
                                                    }}
                                                    className={`feildLabel select ${getClassName({ errors, touched }, 'dataType')}`}
                                                >
                                                    {categoryOption}
                                                </Form.Control>
                                                {renderError({errors, touched }, 'dataType')}
                                            </>
                                        }
                                        labelClassName={"labelClass"}
                                        valueClassName={"valueClass"}
                                        smValue={2}
                                        rowClassName="rowMargin"
                                    />
                                    {
                                        ( values.dataType !== 'list' && values.dataType !== 'checkBox')
                                        ? (
                                            <>
                                                <DetailsLabel 
                                                    labelName={"Data Format"} 
                                                    valueName={
                                                        <>
                                                            <InputText 
                                                                name="dataFormat"
                                                                placeholder={"Enter Data format"} 
                                                                onBlur={handleBlur}
                                                                onChange={ handleChange} 
                                                                value={values.dataFormat} 
                                                                className={`feildLabel ${getClassName({ errors, touched }, 'dataFormat')}`} 
                                                            />
                                                            {renderError({errors, touched }, 'dataFormat')}
                                                        </>
                                                    }
                                                    labelClassName={"labelClass"}
                                                    valueClassName={"valueClass"}
                                                    smValue={2}
                                                    rowClassName="rowMargin"
                                                />
                                            </>
                                        ): ''
                                    }
                                    {                                    
                                        (values.dataType !== 'list' && values.dataType !== 'checkBox')
                                        ? (
                                            <>
                                                <DetailsLabel 
                                                    labelName={"Default Value"} 
                                                    valueName={
                                                        <>
                                                            <FindInputType
                                                                dataType={values.dataType}
                                                                handleChange={(e) => {
                                                                    handleChange(e)
                                                                    setFieldValue('value', e.target.value)
                                                                }}
                                                                onBlur={handleBlur}
                                                                name={"defaultValue"}
                                                                placeholder={'Enter Default Value'}
                                                                dataObj={{setFieldValue,  values}}
                                                                value={values.defaultValue}
                                                                className={`feildLabel ${getClassName({ errors, touched }, 'defaultValue')}`} 
                                                            />
                                                            {renderError({errors, touched }, 'defaultValue')}
                                                        </>
                                                    }
                                                    labelClassName={"labelClass"}
                                                    valueClassName={"valueClass"}
                                                    smValue={2}
                                                    rowClassName="rowMargin"
                                                />
                                            </>
                                        ): null
                                    }
                                    {                                    
                                        (values.dataType === 'integer' || values.dataType === 'decimal')
                                        ? (
                                            <>
                                                <DetailsLabel 
                                                    labelName={"Minimum Value"} 
                                                    valueName={
                                                        <>
                                                            <FindInputType
                                                                dataType={values.dataType}
                                                                handleChange={handleChange}
                                                                onBlur={handleBlur}
                                                                name={"minimumValue"}
                                                                placeholder={'Enter Minimum Value'}
                                                                value={values.minimumValue}
                                                                className={`feildLabel ${getClassName({ errors, touched }, 'minimumValue')}`} 
                                                            />
                                                            {renderError({errors, touched }, 'minimumValue')}
                                                        </>
                                                    }
                                                    labelClassName={"labelClass"}
                                                    valueClassName={"valueClass"}
                                                    smValue={2}
                                                    rowClassName="rowMargin"
                                                />
                                            </>
                                        ):''
                                    }
                                    {                                    
                                        (values.dataType === 'integer'|| values.dataType === 'decimal')
                                        ? (
                                            <>
                                                <DetailsLabel 
                                                    labelName={"Maximum Value"} 
                                                    valueName={
                                                        <>
                                                            <FindInputType
                                                                dataType={values.dataType}
                                                                handleChange={handleChange}
                                                                onBlur={handleBlur}
                                                                name={"maximumValue"}
                                                                placeholder={'Enter Maximum Value'}
                                                                value={values.maximumValue}
                                                                className={`feildLabel ${getClassName({ errors, touched }, 'maximumValue')}`} 
                                                            />
                                                            {renderError({errors, touched }, 'maximumValue')}
                                                        </>
                                                    }
                                                    labelClassName={"labelClass"}
                                                    valueClassName={"valueClass"}
                                                    smValue={2}
                                                    rowClassName="rowMargin"
                                                />
                                            </>
                                        ): ''
                                    }
                                    <DetailsLabel 
                                        labelName={values.dataType !== "list"? "Value":"Datalist Value"} 
                                        valueName={
                                            <>
                                                <FindInputType
                                                    dataType={values.dataType}
                                                    handleChange={handleChange}
                                                    name={values.dataType !== "list"?"value":"dataList"}
                                                    onBlur={handleBlur}
                                                    placeholder={'Enter Value'}
                                                    value={(values.value !== undefined ? values?.value : values.defaultValue)}
                                                    dataObj={{setFieldValue,  values}}
                                                    className={`feildLabel ${getClassName({ errors, touched }, values.dataType !== "list"?"value":"dataList")}`} 
                                                />
                                                {renderError({errors, touched }, values.dataType !== "list"?"value":"dataList")}
                                            </>
                                        }
                                        labelClassName={"labelClass"}
                                        valueClassName={"valueClass"}
                                        smValue={2}
                                        rowClassName="rowMargin"
                                    />
                                    {
                                        (values.dataType === 'list') ? (
                                            <DetailsLabel 
                                                labelName={"Value"} 
                                                valueName={
                                                    <>
                                                        <Form.Control 
                                                            as="select" 
                                                            name={"value"}
                                                            aria-label="Select Category" 
                                                            value={values.value} 
                                                            onBlur={handleBlur}
                                                            onChange={handleChange}
                                                            className={`feildLabel select ${getClassName({ errors, touched }, "value")}`} 
                                                        >
                                                            {
                                                                <>
                                                                    <option value="">Select value</option>
                                                                    {( values.dataList && values.dataList.map((elem) => (
                                                                        <option value={elem}>{elem}</option>
                                                                    )))}
                                                                </>
                                                            }
                                                        </Form.Control>
                                                        {renderError({errors, touched }, "value")}
                                                    </>
                                                }
                                                labelClassName={"labelClass"}
                                                valueClassName={"valueClass"}
                                                smValue={2}
                                                rowClassName="rowMargin"
                                            />
                                        ): ''
                                    }
                                    <DetailsLabel 
                                        labelName={"Required"} 
                                        valueName={
                                            <>
                                                <div className="flex">
                                                    <Switch 
                                                        type="switch"
                                                        name="required"
                                                        onChange={(e) => setFieldValue('required', e.target.checked)}
                                                        id={`custom-switch-${code}-modal`}
                                                        checked={values.required}
                                                    />
                                                    <span className="mt2">{getRequiredText(values.required)}</span>
                                                </div>
                                                {renderError({errors, touched }, 'required')}
                                            </>
                                        }
                                        labelClassName={"labelClass"}
                                        valueClassName={"valueClass"}
                                        smValue={2}
                                        rowClassName="rowMargin"
                                    />
                                    <DetailsLabel 
                                        labelName={"Affected Module"} 
                                        valueName={
                                        <>
                                            <InputText 
                                                name="affectedModule"
                                                onChange={ handleChange}
                                                onBlur={handleBlur} 
                                                placeholder={"Enter Affected Module"} 
                                                value={values.affectedModule}
                                                className={`feildLabel ${getClassName({ errors, touched }, 'affectedModule')}`}  
                                            />
                                            {renderError({errors, touched }, 'affectedModule')}
                                        </>
                                        }
                                        labelClassName={"labelClass"}
                                        valueClassName={"valueClass"}
                                        smValue={2}
                                        rowClassName="rowMargin"
                                    />
                                    <DetailsLabel 
                                        labelName={"Status"} 
                                        valueName={
                                            <>
                                                <div className="flex">
                                                    <Switch 
                                                        name="status"
                                                        type="switch"
                                                        onChange={(e) => setFieldValue('status', e.target.checked)}
                                                        id={`custom-switch-${code}-status-modal`}
                                                        checked={values.status}
                                                    />
                                                    <span className="mt2">{getValueText()}</span>
                                                </div>
                                                {renderError({errors, touched }, 'status')}
                                            </>
                                        }
                                        labelClassName={"labelClass"}
                                        valueClassName={"valueClass"}
                                        smValue={2}
                                        rowClassName="rowMargin"
                                    />
                                   <DetailsLabel 
                                        labelName={"Reason"} 
                                        valueName={
                                            <>
                                                <InputText
                                                    onChange={ handleChange} 
                                                    placeholder={"Enter Reason"} 
                                                    value={values.reason}
                                                    onBlur={handleBlur}
                                                    name="reason"
                                                    className={`feildLabel ${getClassName({ errors, touched }, 'reason')}`}  
                                                />
                                                {renderError({errors, touched }, 'reason')}
                                            </>
                                        }
                                        labelClassName={"labelClass"}
                                        valueClassName={"valueClass"}
                                        smValue={2}
                                        rowClassName="rowMargin"
                                    />
                                </Form>
                            )}
                        </Formik>
                    </Card.Text>
                </Card.Body>
            </Card>
            <div className="settingsBtnBlock">
                <Button variant="secondary" onClick={() => goBack()} >Cancel</Button>
                <Button variant="primary" onClick={() => formIkRef.current.handleSubmit()}>{(id === 'add')? 'Add': 'Save'}</Button>
            </div>
        </div>
    )
}
export default ViewGatewaySettings;
