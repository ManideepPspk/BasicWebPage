import React from 'react';
import {
    Row,
    Col
} from 'react-bootstrap';

function DetailsLabel(props) {
    const {
        labelName,  valueName, labelClassName, valueClassName,
        smValue = 2, rowClassName
    } = props;
    return(
        <Row className={rowClassName}>
            <Col sm={smValue}>
                <label className={labelClassName}>{labelName}</label>
            </Col>
            <Col>
                <div className={valueClassName}>{valueName}</div>
            </Col>
        </Row>
    )
}

export default DetailsLabel;
