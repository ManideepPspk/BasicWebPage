import React, { useState, useEffect } from "react";
import {
  Col,
  Form,
  Row,
  Card,
  Image,
  Spinner,
} from 'react-bootstrap';
import { useDispatch, useSelector } from "react-redux";
import { useHistory  } from 'react-router-dom';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import backIcon from '../../assets/icons/backIcon.png'
import BDOButton from '../Global/Button/BDOButton';
import InputText from '../Global/Input/InputText';
import Switch from '../Global/Switch/Switch';
import ViewDetailsGatewayProviders from './viewDetailGatewayProviderSettings';
import { retrieveGatewayProviders } from '../../actions/gatewaymanagement';
import './styles/viewGatewayRecord.scss';
let initialValues = {};
let dataToBeEdited = {};

const renderError = ( formik, fieldName) => {
  return formik.errors[(fieldName)]? (
    <span className='mb-1 error-text'>
      {formik.errors[(fieldName)]}
    </span>
  ) : null
  }
const getClassName = (formik, fieldName) => {
  let returnMsg = "input-text";
  if( formik.errors[(fieldName)]) return returnMsg+" error"
  return returnMsg
}
export default function ViewGatewayProviders(props) {
  const history = useHistory();
  const dispatch = useDispatch();
    const retData = useSelector( state => state.gatewayReducer);
    //console.log(props , "props in enroll")
   //let propsData = props?.location?.state || {};
  const { match: {params: { id }} } = props;
  console.log(id,"id")
  let iAmNotAdd ;
  if(id!=="ADD" && id!=="undefined"){
    iAmNotAdd = id;
  }
    useEffect(() => {
      
        dispatch(retrieveGatewayProviders(id))
    }, [])
  
    //console.log(retData , "retdata")
    dataToBeEdited = retData?.viewGatewayProviders;
    console.log(dataToBeEdited , "data to be edited")
    let gatewayProviderSettings = [];

    if (iAmNotAdd && dataToBeEdited !== undefined ) {
      let dataToEdit = dataToBeEdited;
      console.log("i am activated" , dataToEdit)
      initialValues.fieldCode = dataToEdit.fieldCode|| '';
      initialValues.fieldName = dataToEdit.fieldName || '';
      initialValues.fieldDescription = dataToEdit.fieldDescription ||'';
      initialValues.status = dataToEdit?.status;
      initialValues.internalAPIInegration = dataToEdit.internalAPIInegration || '';
      initialValues.clientID = dataToEdit.clientID || '';
      initialValues.secretID = dataToEdit.secretID || '';
      initialValues.providerURL = dataToEdit.providerURL || '';
      initialValues.gatewayPort = dataToEdit.gatewayPort || '';
      initialValues.contextRoot = dataToEdit.contextRoot || '';
      initialValues.reason = dataToEdit.reason || '';
      gatewayProviderSettings=dataToEdit.gatewayProviderSettings;
    }
  const formik = useFormik({
    enableReinitialize: true, 
    initialValues,
    validationSchema: Yup.object({
        fieldCode: Yup.string()
        .max(10, 'Must be 10 characters or less')
        .required('Required'),
        fieldName: Yup.string()
        .matches(/^[A-Za-z ]*$/, 'Please enter valid name')
        .max(50, 'Must be 50 characters or less')
        .required('Required'),
        fieldDescription: Yup.string()
        .max(200, 'Must be 200 characters or less')
        .required('Required'),
        internalAPIInegration: Yup.string()
        .max(200, 'Must be 200 characters or less')
        .required('Required'),
        clientID: Yup.string()
        .max(200, 'Must be 200 characters or less')
        .required('Required'),
        secretID: Yup.string()
        .max(200, 'Must be 200 characters or less')
        .required('Required'),
        providerURL: Yup.string()
        .max(200, 'Must be 200 characters or less')
        .required('Required'),
        gatewayPort: Yup.string()
        .max(200, 'Must be 200 characters or less')
        .required('Required'),
        contextRoot: Yup.string()
        .max(200, 'Must be 50 characters or less')
        .required('Required'),
        reason: Yup.string()
        .max(200, 'Must be 50 characters or less')
        .required('Required'),
        status: Yup.string().required('Required')
    }),
    onSubmit: values => {
      console.log(values);
      history.push({pathname: '/gatewayprovider', state: {values}})
    },
  });
    //To initially put gateway status as active for add
    if(!iAmNotAdd){
      if(formik.values.status === undefined){ 
        console.log("i am aehrer")
        formik.values.status ="active";}   
    }      
  const handleSwitchChange = (  name,value ) => {
    if(name === "status"){
      formik.setFieldValue(name, value ? 'active': 'inactive');
    }
}

  function closeModal() {
    formik.resetForm();
    initialValues={};
		history.push("/gatewayprovider");
  }
  return (
    <div className="addCcm viewLayout-gm mt-2">
      <div className="redirect">
                    <Image  onClick={closeModal} src={backIcon}  className="icon"/>
                    <b>{ (iAmNotAdd)?  `${formik.values.fieldCode}`: `Add Gateway Settings`}</b>
                </div>
                
            <Form  onSubmit={formik.handleSubmit}>

            <Card className="cardbodystyle border-0">
               <Card.Body >
                   <Row className="mt-2 mr-2 ml-2">
                       <Col xs='12' sm='12' className="mt-2" ><b>All fields are required</b></Col>
                   </Row>
              <Row  className="mt-2 mr-2 ml-2">
                <Col xs='2' sm='2' >
                  <div className=''>
                    <label htmlFor='fieldCode' className=''>Provider Code </label>
                        
                  </div>
                </Col>
                 <Col xs='5' sm='5'>
                   <InputText 
                          className={getClassName(formik, 'fieldCode')}
                          value={formik.values.fieldCode}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                          disabled={iAmNotAdd ?true : false}
                          name='fieldCode'
                          placeholder='Enter gateway code'
                        />
                         {renderError(formik, 'fieldCode')} 
                  </Col>
              </Row>

              <Row className="mt-2 mr-2 ml-2">
                <Col xs='2' sm='2' >
                  <div className=''>
                    <label htmlFor='fieldName' className=''>Provider Name </label>
                        
                  </div>
                </Col>
                 <Col xs='5' sm='5'>
                    <InputText
                     className={getClassName(formik, 'fieldName')}
                          value={formik.values.fieldName}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                          name='fieldName'
                          placeholder='Enter gateway name'
                        />
                        {renderError(formik, 'fieldName')} 
                  </Col>
              </Row>

              <Row  className="mt-2 mr-2 ml-2">
                <Col xs='2' sm='2' >
                  <div className=''>
                    <label htmlFor='fieldDescription' className=''>Provider Description </label>
                  </div>
                </Col>
                 <Col xs='5' sm='5'>
                         <InputText
                         as="textarea"
                         rows={3}
                         className={getClassName(formik, 'fieldDescription')}
                         value={formik.values.fieldDescription}
                         onChange={formik.handleChange}
                         onBlur={formik.handleBlur}
                         name='fieldDescription'
                         placeholder='Enter gateway description'/>
                        {renderError(formik, 'fieldDescription')} 
                  </Col>
              </Row>
              <Row className="mt-2 mr-2 ml-2">
                <Col xs='2' sm='2' >
                  <div className=''>
                    <label htmlFor='internalAPIInegration' className=''>Internal API Integration</label>
                        
                  </div>
                </Col>
                 <Col xs='5' sm='5'>
                    <InputText
                     className={getClassName(formik, 'internalAPIInegration')}
                          value={formik.values.internalAPIInegration}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                          name='internalAPIInegration'
                          placeholder='Enter internalAPIInegration'
                        />
                        {renderError(formik, 'internalAPIInegration')} 
                  </Col>
              </Row>
              <Row className="mt-2 mr-2 ml-2">
                <Col xs='2' sm='2' >
                  <div className=''>
                    <label htmlFor='clientID' className=''>Client ID</label>
                        
                  </div>
                </Col>
                 <Col xs='5' sm='5'>
                    <InputText
                     className={getClassName(formik, 'clientID')}
                          value={formik.values.clientID}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                          name='clientID'
                          placeholder='Enter clientID'
                        />
                        {renderError(formik, 'clientID')} 
                  </Col>
              </Row>
              <Row className="mt-2 mr-2 ml-2">
                <Col xs='2' sm='2' >
                  <div className=''>
                    <label htmlFor='secretID' className=''>Secret ID</label>
                        
                  </div>
                </Col>
                 <Col xs='5' sm='5'>
                    <InputText
                     className={getClassName(formik, 'secretID')}
                          value={formik.values.secretID}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                          name='secretID'
                          placeholder='Enter secretID'
                        />
                        {renderError(formik, 'secretID')} 
                  </Col>
              </Row>
              <Row className="mt-2 mr-2 ml-2">
                <Col xs='2' sm='2' >
                  <div className=''>
                    <label htmlFor='providerURL' className=''>Provider URL</label>
                        
                  </div>
                </Col>
                 <Col xs='5' sm='5'>
                    <InputText
                     className={getClassName(formik, 'providerURL')}
                          value={formik.values.providerURL}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                          name='providerURL'
                          placeholder='Enter providerURL'
                        />
                        {renderError(formik, 'providerURL')} 
                  </Col>
              </Row>
              <Row className="mt-2 mr-2 ml-2">
                <Col xs='2' sm='2' >
                  <div className=''>
                    <label htmlFor='gatewayPort' className=''>Gateway Port</label>
                        
                  </div>
                </Col>
                 <Col xs='5' sm='5'>
                    <InputText
                     className={getClassName(formik, 'gatewayPort')}
                          value={formik.values.gatewayPort}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                          name='gatewayPort'
                          placeholder='Enter gatewayPort'
                        />
                        {renderError(formik, 'gatewayPort')} 
                  </Col>
              </Row>
              <Row className="mt-2 mr-2 ml-2">
                <Col xs='2' sm='2' >
                  <div className=''>
                    <label htmlFor='contextRoot' className=''>Context Root</label>
                        
                  </div>
                </Col>
                 <Col xs='5' sm='5'>
                    <InputText
                     className={getClassName(formik, 'contextRoot')}
                          value={formik.values.contextRoot}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                          name='contextRoot'
                          placeholder='Enter contextRoot'
                        />
                        {renderError(formik, 'contextRoot')} 
                  </Col>
              </Row>
              <Row  className="mt-2 mr-2 ml-2">
                <Col xs='2' sm='2' >
                  <div className=''>
                    <label htmlFor='status' className=''>Provider Status</label>
                  </div>
                </Col>
                 <Col xs='5' sm='5'>
                 
            <div className="detailsActive">
            <Switch
                type="switch"
                id={`custom-switch-${formik?.values?.fieldCode}`}
                onChange={(e) => handleSwitchChange( "status" , e.target.checked)}
                checked={formik.values.status === "active" ?true : false}
            />
                                    <div>{formik.values.status === "active" ? 'Active' : 'Inactive'}</div>
                                </div>
                                {renderError(formik, 'status')}
                       
                  </Col>
              </Row>
              
              <Row className="mt-2 mr-2 ml-2">
                <Col xs='2' sm='2' >
                  <div className=''>
                    <label htmlFor='reason' className=''>Reason </label>
                        
                  </div>
                </Col>
                 <Col xs='5' sm='5'>
                    <InputText
                     className={getClassName(formik, 'reason')}
                          value={formik.values.reason}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                          name='reason'
                          placeholder='Enter reason'
                        />
                        {renderError(formik, 'reason')} 
                  </Col>
              </Row>
              </Card.Body>
              </Card>
              
              <div className="subDetails">
                <Card><Card.Body>
                    <ViewDetailsGatewayProviders
                        gatewayProviderSettings = {gatewayProviderSettings }   
                        providercode={initialValues.fieldCode}      
                    />
                    </Card.Body>
                </Card>
            </div>
            <div className='mt-4 mb-4 float-right'>
                <BDOButton  onClick={closeModal} title="Cancel" style1="style2 mr-3" />
                <BDOButton type="submit" title={(iAmNotAdd)
                    ? 'Save'
                    : 'Add'} style1="style1" />
              </div>
            </Form>
    </div>
  );
}

