import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from "react-redux";
import {
    Card, Row, Col,
    Image, ListGroup
} from 'react-bootstrap';
import EditIcon from '../../assets/icons/icon-edit-outline.svg';
import UnlockIcon from '../../assets/icons/unlock-outline.svg';
import Switch from '../Global/Switch/Switch';
import { retrieveAllChannal }  from '../../actions/gatewaymanagement';
import ChannelList from './ChannelList.js';
import './styles/viewAllChannal.scss';
    
const editIcon = (<Image src={EditIcon} className="icon"/>);    
const unlockIcon = (<Image src={UnlockIcon} className="icon"/>);

const actionDiv = ( ele, handleStatusChange ) => (
    (ele.status ==="active" || ele.status ==="inactive")
    ? (<div className="actionDiv" key={`action_${ele.code}`}>
            <Switch
                    type="switch"
                    id={`custom-switch-${ele.code}`}
                    defaultChecked={ele.status === 'active'}
                    onChange={(e) => handleStatusChange(e.target.checked, ele.code)}
                />
            <div className="editDiv">{editIcon}</div>
        </div>
    ): ''
)


const alphaNumericSorting = (frstValue, scndValue, colId, desc=false) => {
    if( frstValue && scndValue ){
        if( !desc ) return frstValue.localeCompare(scndValue)
        return (-1 *(scndValue.localeCompare(frstValue)))
    }
}

const statusDiv = (rowData) => {
    const { status } = rowData;
    let className = '';
    let text = '';
    if( status === "blocked") {
        className = "status"+status;
        text= status[0].toUpperCase() + status.substring(1, status.length)
    }
    return ( <div className={className}><b>{text}</b></div>)
};

const unlockImgDiv = (rowData) => {
    const { status } = rowData;
    let className = '';
    let unlock_img = '';
    if( status === "blocked") {
        className = "un"+status+"img";
        unlock_img= unlockIcon
    }
    return ( <div className={className}>{unlock_img}</div>)
};

const sortByElement = ( rowA, rowB, colId, desc) => {
    const findFn = ( entry ) => entry.column && (entry.column.id ===  colId)
    const foundAData = rowA.cells.find(findFn);
    const foundBData = rowB.cells.find(findFn);
    const aValue =  typeof rowA.cells[0] !== "function" && foundAData && foundAData.value.props.children;
    const bValue =  typeof rowB.cells[0] !== "function" && foundBData && foundBData.value.props.children;
    return alphaNumericSorting( aValue, bValue, colId, desc)
}

function ViewAllChannels(props) { 
    const { isupdate, iscreate } = props;
    const dispatch = useDispatch();
    const retData = useSelector( state => state.gatewayReducer);
    let { viewAllChannal=[] }  = retData;
    const { data={}, totalPages=1} = viewAllChannal;
    const {channel_list = [], channel_summary = {}} = data
    useEffect(() => {
        dispatch(retrieveAllChannal(`page=${0}&size=${10}`));           
    }, []);
    let [ localData=channel_list, setData] = useState();
    let [ activeRow, setActiveRow] = useState([]);

    let columns = [
        {
            Header: 'Channel Code',
            accessor: 'code',
            selector: 'code',
            sortType: 'basic',
        },
        {
            Header: 'Sender',
            accessor: 'sender',
            sortType: 'basic',
        },
        {
            Header: 'Gateway Type',
            accessor: 'gateway_type',
            sortType: 'basic',
        },
        {
            Header: 'Rate',
            accessor: 'rate',
            sortType: 'basic',
        },
        {
            Header: 'Max. Rate',
            accessor: 'max_rate',
            sortType: 'basic',
        },
        {
            Header: 'Thres. Rate',
            accessor: 'thres_rate',
            sortType: 'basic',
        },
        {
            Header: 'Status',
            accessor: 'status',
            disableSortBy: true,
        },
        {
            Header: 'Update Date',
            accessor: 'update_date',
            sortType: 'basic',
        },
        {
            Header: '',
            accessor: 'blockImg',
            disableSortBy: true,
        },
    ];
    if( isupdate ) {
        columns = [ 
            ...columns,  {
                Header: '',
                accessor: 'actions',
                disableSortBy: true,
            }
        ];
    }

    const handleServerSidePagination = ( pageNo, pageSize ) => {
        dispatch(retrieveAllChannal(`page=${pageNo}&size=${pageSize}`));
    }
    
    const  handleClick = ( category, ipText ) => {
        
        const categoryFilterdData = [ ...data ].filter(( ele ) => ele.code === ipText);
        setData(categoryFilterdData );
    }
    const handleStatusChange = ( value, code ) => {
        const finder = data.find(( ele ) => ele.code === code);
        finder["status"] = value?"active": "inactive";
        setData([...data]);
    }
    const localObj = localData && localData.map((ele) => {
            return {
                ...ele,
                status: statusDiv(ele),
                actions: actionDiv(ele, handleStatusChange),
                blockImg: unlockImgDiv(ele),
                className: (ele.status === 'blocked' ) ? 'blocked' :'',
            }
        });
        
    const handleBlockedList = () => {
        const tempData = channel_list.filter(elem => elem.status === "blocked")
        setData(tempData);
    }

    const handleReachedThresholdList = () => {
        const tempData = channel_list.filter(elem => elem.status !== "blocked" && (Number(elem.rate.replace("%","")) >= Number(elem.thres_rate.replace("%",""))))
        setData(tempData);
    }


    const blockedTotal = channel_summary.blocked && Object.keys(channel_summary.blocked).reduce((ele,nextele) => channel_summary.blocked[ele] + channel_summary.blocked[nextele])
    const reachedThreasholdTot = channel_summary.reached_threashold && Object.keys(channel_summary.reached_threashold).reduce((ele,nextele) => channel_summary.reached_threashold[ele] + channel_summary.reached_threashold[nextele])
    return(
        <div className="gateWayTypeManagement">
            <div className="headerBlock">
                <div>
                    <b>View Channel Status</b>
                </div>
            </div>
            <div className="tableBlock">
                <Row>
                    <Col sm={3}> 
                        <div className='leftBox'>
                            <Card>
                                <Card.Body>
                                    <b>Channel Summary </b>
                                    <ListGroup className="mt15" onClick={() => handleBlockedList()}> 
                                        <ListGroup.Item className="flexDiv blocked"><div><b>Blocked</b></div><div><b>{blockedTotal}</b></div></ListGroup.Item>
                                        {channel_summary.blocked && Object.keys(channel_summary.blocked).map(ele => (
                                            <ListGroup.Item className="flexDiv"><div>{ele.toUpperCase()}</div><div><b>{channel_summary.blocked[ele]}</b></div></ListGroup.Item>
                                        ))}
                                    </ListGroup>
                                    <ListGroup className="thresBox" onClick={() => handleReachedThresholdList()}> 
                                        <ListGroup.Item className="flexDiv threshold"><div><b>Reached Threshold</b></div><div><b>{reachedThreasholdTot}</b></div></ListGroup.Item>
                                        {channel_summary.reached_threashold && Object.keys(channel_summary.reached_threashold).map(ele => (
                                            <ListGroup.Item className="flexDiv"><div>{ele.toUpperCase()}</div><div><b>{channel_summary.reached_threashold[ele]}</b></div></ListGroup.Item>
                                        ))}
                                    </ListGroup>
                                </Card.Body>
                            </Card>
                        </div>
                    </Col>
                    <Col sm={9} className="padding0"> 
                        <div className='rightBox'>
                            <Card>
                                <Card.Body >
                                    <ChannelList data={localObj} col={columns} handleClick={handleClick} />
                                </Card.Body>
                            </Card>
                        </div>
                    </Col>
                </Row>
            </div>

        </div>
    )
}
export default ViewAllChannels;
