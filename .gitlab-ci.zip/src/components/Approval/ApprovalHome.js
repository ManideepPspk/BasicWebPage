import React, { useState } from 'react';
import {
    Card,Tab, Tabs
} from 'react-bootstrap';
import PendingList from './PendingList';
import ApprovedList from './ApprovedList';
import RejectedList from './RejectedList';
import BDOToast from '../Global/BDOToast/BDOToast';
import './styles/AprovalHome.scss';

function ApprovalHome(props) { 
    const [key, setKey] = useState('pending');
    const [ toastState, setToastState ] = useState(false);
	const [ toastData, setToastData ] = useState({});
    const onToastClose = () => {
		setToastState(false);
        setToastData({});
	}
    return(
        <div className="approvalHome">
            <div className="headerBlock">
                <div>
                    <b>My Approvals</b>
                </div>
            </div>
            {
				toastState && (
					<BDOToast  
						openState={toastState}
						type={"success"}
						bodyMessage={`${toastData.message}. Reference No: ${toastData.reference_number}`}
						onClose={onToastClose} 
					/>
				)
			}
            <Card>
                <Card.Body>
                    <div className="tabBlock">
                        <div>
                            <Tabs 
                                activeKey={key}
                                onSelect={(k) => setKey(k)} 
                                id="uncontrolled-tab-example"
                            >
                                <Tab eventKey="pending" title="Pending">
                                    <PendingList setToastState={setToastState} setToastData={setToastData} />
                                </Tab>
                                <Tab eventKey="approved" title="Approved">
                                    <ApprovedList />
                                </Tab>
                                <Tab eventKey="rejected" title="Rejected">
                                    <RejectedList />
                                </Tab>
                            </Tabs>
                        </div>
                    </div>
                </Card.Body>
            </Card>
        </div>
    )
}
export default ApprovalHome;
