import React, { useEffect, useState, useRef } from 'react';
import { useDispatch, useSelector } from "react-redux";
import {
    Card, Row, Col, Button,
    Image, Spinner
} from 'react-bootstrap';
import { useHistory, Link } from 'react-router-dom';
import SearchBar from '../Global/SearchBar/SearchBar';
import DataTable from '../Global/DataTable/DataTable';
import EditIcon from '../../assets/icons/icon-edit-outline.svg';
import DeleteIcon from "../../assets/icons/icon-delete-outline.svg";
import Switch from '../Global/Switch/Switch';
import BDOModal from '../Global/BDOModal/BDOModal';
import CcmModalBody from './CcmModalBody';
import { retrieveAllCCMParameter, updateCCMStatus }  from '../../actions/ccmparameter';
import BDOToast from '../Global/BDOToast/BDOToast';
import './styles/ViewAllCcmParameter.scss';

const delIcon = <Image src={DeleteIcon} className="icon" />;
const editIcon =(rowData , toggle)=> (<Image onClick={() => toggle('EDIT' , rowData)} src={EditIcon} className="icon"/>);
const actionDiv = (ele, handleStatusChange , toggle) =>
  ele.status === "active" || ele.status === "inactive" ? (
    <div className="actionDiv">
      <div onClick={(e) => handleStatusChange(e, ele)}>
        <Switch
          type="switch"
          id={`custom-switch-${ele.code}`}
          checked={ele.status === "active"}
        />
    	</div>     
	    <div className="editDiv">{editIcon(ele , toggle)}</div>
      <div className="deleteDiv">{delIcon}</div>
  </div>
) : (
  ""
);

const alphaNumericSorting = (frstValue, scndValue, colId, desc = false) => {
  if (frstValue && scndValue) {
    if (!desc) return frstValue.localeCompare(scndValue);
    return -1 * scndValue.localeCompare(frstValue);
  }
};

const statusDiv = (rowData) => {
  const { status } = rowData;
  let className = "forApproval";
  let text = "For Approval";
  if (status === "active" || status === "inactive") {
    className = "status" + status;
    text = status[0].toUpperCase() + status.substring(1, status.length);
  }
  return <div className={className}>{text}</div>;
};

function ViewAllCcmParameter(props) {
  const history = useHistory();
  const dispatch = useDispatch();
  const retData = useSelector((state) => state.ccmparameter);
  let { viewAllCcmParameter = [] } = retData;

  let { data, totalPages = 1 } = viewAllCcmParameter;
  useEffect(() => {
    dispatch(retrieveAllCCMParameter(`page=${0}&size=${10}`));
  }, []);
  let propsData = props?.location?.state;
  let [localData = data, setData] = useState();
  const [ modalState, setModalState ] = useState(false);
  const [ modalData, setModalData ] = useState({});
	const [ toastState, setToastState ] = useState(false);
	const [ toastData, setToastData ] = useState({});
  const formIkRef = useRef();

  let [activeRow, setActiveRow] = useState([]);
  let toggle = (toggleaction , datatochild) => {
    history.push({pathname: '/ccmparameter/addccmparameter', state: {toggleaction,datatochild }})
  };
  const closeModal = () => {
		setModalData({});
		setModalState(false);
		setData([...localData]);
	}

useEffect(() => {
  let message = propsData?.data?.message;
  let reference_number = propsData?.data?.reference_number;
  if(message!==undefined && reference_number!==undefined){
    setToastState(true);
  setToastData({ message, reference_number, type: "success"});
  }
}, [propsData?.data]);

const handleOnChangeStatus = ( reqObj ) => {
		dispatch(updateCCMStatus(reqObj, (respData) => {
      const { data : { message, reference_number }} = respData;
      const finder = data.find(( ele ) => ele.code === reqObj.code);
      finder["status"] = finder.status === "inactive"?"active": "inactive";
      setData([...data]);
      setToastState(true);
      setToastData({ message, reference_number, type: "success"});
      closeModal();
      window.scrollTo({
        top: 0,
        left:0,
        behavior: "smooth"
      });
    }));
	}


  const categoryList = [
      {'key': 'CCM Code', 'value': 'code'},
      {'key': 'CCM Name', 'value': 'name'},
      {'key': 'CCM Description', 'value': 'description'}
  ];

  const handleHeaderCheck = (value) => {
    value === true
      ? setActiveRow([...localData.map((entry) => entry.code)])
      : setActiveRow([]);
  };
  const columns = [
    {
      Header: <Switch onClick={(e) => handleHeaderCheck(e.target.checked)} />,
      accessor: "checkBox",
      disableSortBy: true,
    },
    {
      Header: "CCM Code",
      accessor: "code",
      selector: "code",
      sortType: "basic",
    },
    {
      Header: "CCM Name",
      accessor: "name",
      sortType: (rowA, rowB, colId, desc) => {
        const findFn = (entry) => entry.column && entry.column.id === colId;
        const foundAData = rowA.cells.find(findFn);
        const foundBData = rowB.cells.find(findFn);
        const aValue =
          typeof rowA.cells[0] !== "function" &&
          foundAData &&
          foundAData.value.props.children;
        const bValue =
          typeof rowB.cells[0] !== "function" &&
          foundBData &&
          foundBData.value.props.children;
        return alphaNumericSorting(aValue, bValue, colId, desc);
      },
    },
    {
      Header: "CCM Description",
      accessor: "description",
    },
    {
      Header: "Status",
      accessor: "status",
    },
    {
      Header: "Actions",
      accessor: "actions",
      disableSortBy: true,
    },
  ];

  const handleServerSidePagination = (pageNo, pageSize) => {
    dispatch(retrieveAllCCMParameter(`page=${pageNo}&size=${pageSize}`));
  };

  const handleClick = (category, ipText) => {
    const condtnFn = (ele) => {
      return ele["name"].toLowerCase().includes(ipText.toLowerCase()) ||  ele["code"].toLowerCase().includes(ipText.toLowerCase()) ;
    }
    const categoryFilterdData = [...data].filter(condtnFn);
    setData(categoryFilterdData);
  };
  const linkDiv = (rowData) => (
    <Link to={`/ccmparameter/${rowData.code}`}>{rowData.name}</Link>
  );
  const handleStatusChange = (e, valueObj) => {
    e.stopPropagation();
		if (e.target.checked) {
      valueObj = { ...valueObj, modalHeader: 'Enable CCM parameter', changedState: 'Enable'}
    } else {
      valueObj = { ...valueObj, modalHeader: 'Disable CCM parameter',  changedState: 'Disable'}
    }
		setModalState(true);
    setModalData(valueObj);
  };

  const handleCheckList = (value, code) => {
    const idx = activeRow.indexOf(code);
    if (value) setActiveRow([...activeRow, code]);
    else {
      activeRow.splice(idx, 1);
      setActiveRow([...activeRow]);
    }
  };
  const localObj =
    localData &&
    localData.map((ele) => {
      return {
        checkBox: (
          <Switch
            onChange={(e) => handleCheckList(e.target.checked, ele.code)}
            checked={activeRow.indexOf(ele.code) !== -1}
          />
        ),
        ...ele,
        name: linkDiv(ele),
        status: statusDiv(ele),
        actions: actionDiv(ele, handleStatusChange , toggle),
        className: activeRow.find((itr) => itr === ele.code) ? "activeRow" : "",
      };
    });	
    const modalFooterContent = (
		<div>
			<Button variant="secondary" onClick={closeModal}>Cancel</Button>
			<Button variant="primary" onClick={() => formIkRef.current.handleSubmit()}>
				{modalData.changedState}
			</Button>
		</div>
	);

	const onToastClose = () => {
		setToastState(false);
    setToastData({});
    if (history.location.state && history.location.state.data) {
      let state = { ...history.location.state };
      delete state.data;
      history.replace({ ...history.location, state });
    }
	}


  return (
    <div className="ccmParameter">
      <div className="headerBlock">
        <div>
          <b>CCM Parameter</b>
        </div>
        <div className="buttonBlock">
            <Button variant="primary"  onClick={(e) => toggle('ADD')} >Add CCM Parameter</Button>
        </div>
      </div>
			{
				toastState && (
					<BDOToast  
						openState={toastState}
						type={"success"}
						bodyMessage={`${toastData.message}. Reference No: ${toastData.reference_number}`}
						onClose={onToastClose} 
					/>
				)
			}
      <Card className="searchBlock">
        <Card.Body>
          <div className="searchCard">
            <Row className="mb10">
              <Col sm={8}>
                <b className="ml10">Search CCM Parameter</b>
              </Col>
            </Row>
            <div className="formBlock">
              <SearchBar
                textPlaceHolder="Enter CCM Parameter"
                handleClick={handleClick}
                categoryList={categoryList}
              />
            </div>
          </div>
        </Card.Body>
      </Card>
      <div className="tableBlock">
        <Card>
          <Card.Body>
          <div  className="mb10">
              <b className="header6">CCM Parameter</b>
          </div>
            <div className="btnBlock">
              {activeRow.length > 0 ? (
                <>
                  <Button variant="primary" className="danger">
                    Deactive
                  </Button>
                  <span className="highlighter">
                    {activeRow.length} items selected
                  </span>
                </>
              ) : (
                ""
              )}
            </div>
            <div className="dataBlock">
              {localObj !== undefined ? (
                <DataTable
                  columns={columns}
                  data={localObj}
                  showPagination={true}
                  // handleServerSidePagination={handleServerSidePagination}
                  pageProperty={{ totalPages }}
                />
              ) : (
                <div className="alignCenter">
                  <Spinner animation="border" />
                </div>
              )}
            </div>
          </Card.Body>
        </Card>
      </div>
      {
        modalState && (
					<BDOModal
						header={modalData.modalHeader}
						body={
							<CcmModalBody 
								modalData={modalData} 
								setModalData={setModalData} 
								formIkRef={formIkRef}
								handleOnChangeStatus={handleOnChangeStatus}
							/>}
						footer={modalFooterContent}
						openState={modalState}
						modalProps={{onHide:closeModal}}
					/>
        )
      }
    </div>
  );
}
export default ViewAllCcmParameter;
