import React from 'react';
import InputText from '../Global/Input/InputText';
import { Form } from 'react-bootstrap';
import { Formik } from 'formik';
import * as Yup from 'yup';

const validationSchema = Yup.object().shape({
	reason: Yup.string().required('Required feild'),
});

const CcmModalBody = (props) => {
	const { modalData, handleOnChangeStatus, formIkRef } = props;
	return (
		<div>
			<div>
				{modalData.header}
			</div>
			<div className="bdyRow">
				<b>CCM Parameter Code : </b>
				<span>{modalData.code}</span>
			</div>
			<div className="bdyRow">
				<b>CCM Parameter Name : </b>
				<span>{modalData.name}</span>
			</div>
			<div className="bdyRow">
				<b>CCM Parameter Description : </b>
				<span>{modalData.description}</span>
			</div>
			<div className="bdyRow reasonBlock">
				<Formik
					initialValues={{'reason':'', code: modalData.code}}
					validationSchema={validationSchema}
					innerRef={formIkRef}
					onSubmit={(values) => handleOnChangeStatus(values)}
				>
					{({ 
                errors, touched, values, handleSubmit, handleChange,
            }) => (
                    <Form onSubmit={handleSubmit}>
                        <InputText  
                            value={modalData.reason} 
                            onChange={handleChange}
                            placeholder="Please provide reason"
                            name="reason"
                        />
                        {
                            errors.reason && touched.reason
                            ?(
                                <div className="alignLeft"> 
                                    <span className="err-feild">
                                        {errors.reason}
                                    </span>
                                </div>
                            ): ''
                        }
                    </Form>
                )}
            </Formik>
        </div>
    </div>
	)
};

export default CcmModalBody;
