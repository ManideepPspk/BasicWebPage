import React, { useEffect } from 'react';
import { Image } from 'react-bootstrap';
import ViewCCMDetails from './ViewCCMDetails';
import { useDispatch, useSelector } from "react-redux";
import { retrieveCCMRecord }  from '../../actions/ccmparameter';
import { Link } from "react-router-dom";
import backIcon from '../../assets/icons/backIcon.png'

import './styles/viewCCMRecord.scss';

function ViewCCMRecord(props) {
    const dispatch = useDispatch();
    const retData = useSelector( state => state.ccmparameter);
    useEffect(() => {
        const { match: {params: { id }}  } = props;
        dispatch(retrieveCCMRecord(id))
    }, [])
    const { viewCcmParameter={} } = retData;
    const { data= { } } =viewCcmParameter;
    const { ccmParameterDetails={}} = data;
    return(
        <div className="viewLayout">
            <div className="redirect">
                <Link to={"/ccmparameter"}>
                    <Image src={backIcon}  className="icon"/>
                </Link>
                <b>MCG1234567</b>
            </div>
            <div>
                { 
                    data &&
                    <ViewCCMDetails ccmParameterDetails={ ccmParameterDetails} />
                }
            </div>          
        </div>
    )
}

export default ViewCCMRecord;
