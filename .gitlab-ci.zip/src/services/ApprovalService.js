import http from "../http-common";

const getAll = () => {
    return http.get("/b/W5R5");
};
const getAllApproval = () => {
    return http.get("/b/FMGQ");
};

const getAllRejected = () => {
    return http.get("/b/XWYC");
};



const ApprovalService = {
    getAll,
    getAllRejected,
    getAllApproval
  };
  
  export default ApprovalService;
  