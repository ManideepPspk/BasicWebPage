import http from "../http-common";

const getAll = (paramsData='') => {
  const reqData = paramsData ? `?${paramsData}`:''
  return http.get(`/b/RH4O${reqData}`);
};

const get = paramsData => {
  return http.get(`/b/IWGE?${paramsData}`);
};

const getAllGatewayProvider = () => {
  return http.get("/b/O06V");
};


const create = data => {
  return http.post("/posts", data);
};

const update = (id, data) => {
  return http.put(`/posts/${id}`, data);
};

const remove = id => {
  return http.delete(`/posts/${id}`);
};

const removeAll = () => {
  return http.delete(`/posts`);
};

const findByTitle = title => {
  return http.get(`/posts?title=${title}`);
};

const getGatewaySettings = id => {
  return http.get(`/b/ZG8W?${id}`);
};

const getGatewayProviders = id => {
  return http.get(`/b/FTWN?${id}`);
}

const getGatewayProviderSetting = id => {
  return http.get(`/b/M8NU?${id}`);
}

const getAllChannal = () => {
  return http.get(`/b/2AUZ`);
}


const GatewayService = {
  getAll,
  get,
  getAllGatewayProvider,
  create,
  update,
  remove,
  removeAll,
  findByTitle,
  getGatewaySettings,
  getGatewayProviders,
  getGatewayProviderSetting,
  getAllChannal
};

export default GatewayService;
